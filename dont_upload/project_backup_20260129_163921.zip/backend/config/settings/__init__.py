"""Settings package"""
