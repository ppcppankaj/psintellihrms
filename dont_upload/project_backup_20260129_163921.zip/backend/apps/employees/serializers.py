"""
Employee Serializers
"""

from rest_framework import serializers
from apps.authentication.serializers import UserSerializer
from .models import (
    Employee, Department, Designation, Location,
    EmployeeAddress, EmployeeBankAccount, EmergencyContact,
    EmployeeDependent, Skill, EmployeeSkill, 
    EmploymentHistory, Document,
    EmployeeTransfer, EmployeePromotion, ResignationRequest, ExitInterview
)


class DepartmentSerializer(serializers.ModelSerializer):
    """Department serializer"""
    
    employee_count = serializers.SerializerMethodField()
    parent_name = serializers.CharField(source='parent.name', read_only=True)
    head_name = serializers.CharField(source='head.full_name', read_only=True)
    
    class Meta:
        model = Department
        fields = [
            'id', 'name', 'code', 'description', 'parent', 'parent_name',
            'head', 'head_name', 'cost_center', 'employee_count', 'is_active'
        ]
        read_only_fields = ['id']
    
    def get_employee_count(self, obj):
        return obj.employees.filter(is_active=True).count()


class DesignationSerializer(serializers.ModelSerializer):
    """Designation serializer"""
    
    class Meta:
        model = Designation
        fields = [
            'id', 'name', 'code', 'description', 'level',
            'grade', 'job_family', 'min_salary', 'max_salary', 'is_active'
        ]
        read_only_fields = ['id']


class LocationSerializer(serializers.ModelSerializer):
    """Location serializer"""
    
    class Meta:
        model = Location
        fields = [
            'id', 'name', 'code', 'address_line1', 'address_line2',
            'city', 'state', 'country', 'postal_code',
            'latitude', 'longitude', 'geo_fence_radius',
            'phone', 'email', 'timezone', 'is_headquarters', 'is_active'
        ]
        read_only_fields = ['id']


class EmployeeListSerializer(serializers.ModelSerializer):
    """Lightweight employee serializer for lists"""
    
    full_name = serializers.ReadOnlyField()
    email = serializers.ReadOnlyField()
    department_name = serializers.CharField(source='department.name', read_only=True)
    designation_name = serializers.CharField(source='designation.name', read_only=True)
    location_name = serializers.CharField(source='location.name', read_only=True)
    manager_name = serializers.CharField(source='reporting_manager.full_name', read_only=True)
    avatar = serializers.ImageField(source='user.avatar', read_only=True)
    
    class Meta:
        model = Employee
        fields = [
            'id', 'employee_id', 'full_name', 'email', 'avatar',
            'department_name', 'designation_name', 'location_name',
            'manager_name', 'employment_type', 'employment_status',
            'date_of_joining', 'is_active'
        ]


class EmployeeAddressSerializer(serializers.ModelSerializer):
    """Employee address serializer"""
    
    class Meta:
        model = EmployeeAddress
        fields = [
            'id', 'address_type', 'address_line1', 'address_line2',
            'city', 'state', 'country', 'postal_code', 'is_primary'
        ]
        read_only_fields = ['id']


class EmployeeBankAccountSerializer(serializers.ModelSerializer):
    """Employee bank account serializer"""
    
    masked_account_number = serializers.SerializerMethodField()
    
    class Meta:
        model = EmployeeBankAccount
        fields = [
            'id', 'account_holder_name', 'bank_name', 'branch_name',
            'account_number', 'masked_account_number', 'ifsc_code', 'account_type', 'is_primary'
        ]
        read_only_fields = ['id']
        extra_kwargs = {
            'account_number': {'write_only': True}
        }
    
    def get_masked_account_number(self, obj):
        if obj.account_number:
            return 'X' * (len(obj.account_number) - 4) + obj.account_number[-4:]
        return None


class EmergencyContactSerializer(serializers.ModelSerializer):
    """Emergency contact serializer"""
    
    class Meta:
        model = EmergencyContact
        fields = [
            'id', 'name', 'relationship', 'phone',
            'alternate_phone', 'email', 'address', 'is_primary'
        ]
        read_only_fields = ['id']


class EmployeeDependentSerializer(serializers.ModelSerializer):
    """Employee dependent serializer"""
    
    class Meta:
        model = EmployeeDependent
        fields = [
            'id', 'name', 'relationship', 'date_of_birth',
            'gender', 'is_covered_in_insurance', 'is_disabled'
        ]
        read_only_fields = ['id']


class SkillSerializer(serializers.ModelSerializer):
    """Skill serializer"""
    
    class Meta:
        model = Skill
        fields = ['id', 'name', 'category', 'description', 'is_active']
        read_only_fields = ['id']


class EmployeeSkillSerializer(serializers.ModelSerializer):
    """Employee skill serializer"""
    
    skill = SkillSerializer(read_only=True)
    skill_id = serializers.UUIDField(write_only=True)
    
    class Meta:
        model = EmployeeSkill
        fields = [
            'id', 'skill', 'skill_id', 'proficiency',
            'years_of_experience', 'is_primary', 'is_verified'
        ]
        read_only_fields = ['id', 'is_verified']


class EmploymentHistorySerializer(serializers.ModelSerializer):
    """Employment history serializer"""
    
    previous_department_name = serializers.CharField(source='previous_department.name', read_only=True)
    new_department_name = serializers.CharField(source='new_department.name', read_only=True)
    previous_designation_name = serializers.CharField(source='previous_designation.name', read_only=True)
    new_designation_name = serializers.CharField(source='new_designation.name', read_only=True)
    
    class Meta:
        model = EmploymentHistory
        fields = [
            'id', 'change_type', 'effective_date',
            'previous_department', 'previous_department_name',
            'new_department', 'new_department_name',
            'previous_designation', 'previous_designation_name',
            'new_designation', 'new_designation_name',
            'previous_location', 'new_location',
            'previous_manager', 'new_manager',
            'remarks', 'created_at'
        ]
        read_only_fields = ['id', 'created_at']


class DocumentSerializer(serializers.ModelSerializer):
    """Document serializer"""
    
    class Meta:
        model = Document
        fields = [
            'id', 'document_type', 'name', 'description',
            'file', 'file_size', 'file_type',
            'is_verified', 'verified_by', 'verified_at',
            'expiry_date', 'is_confidential', 'created_at'
        ]
        read_only_fields = ['id', 'file_size', 'file_type', 'is_verified', 'verified_by', 'verified_at', 'created_at']


class EmployeeDetailSerializer(serializers.ModelSerializer):
    """Full employee detail serializer"""
    
    user = UserSerializer(read_only=True)
    department = DepartmentSerializer(read_only=True)
    designation = DesignationSerializer(read_only=True)
    location = LocationSerializer(read_only=True)
    reporting_manager = EmployeeListSerializer(read_only=True)
    hr_manager = EmployeeListSerializer(read_only=True)
    
    addresses = EmployeeAddressSerializer(many=True, read_only=True)
    bank_accounts = EmployeeBankAccountSerializer(many=True, read_only=True)
    emergency_contacts = EmergencyContactSerializer(many=True, read_only=True)
    dependents = EmployeeDependentSerializer(many=True, read_only=True)
    skills = EmployeeSkillSerializer(many=True, read_only=True)
    
    direct_reports_count = serializers.SerializerMethodField()
    
    class Meta:
        model = Employee
        fields = [
            'id', 'employee_id', 'user',
            'date_of_birth', 'gender', 'marital_status', 'blood_group', 'nationality',
            'department', 'designation', 'location',
            'reporting_manager', 'hr_manager',
            'employment_type', 'employment_status',
            'date_of_joining', 'confirmation_date', 'probation_end_date',
            'notice_period_days', 'date_of_exit', 'exit_reason', 'last_working_date',
            'work_mode',
            'pan_number', 'aadhaar_number', 'passport_number', 'passport_expiry',
            'uan_number', 'pf_number', 'esi_number',
            'bio', 'linkedin_url',
            'addresses', 'bank_accounts', 'emergency_contacts',
            'dependents', 'skills', 
            'direct_reports_count', 'roles',
            'is_active', 'created_at', 'updated_at'
        ]
        read_only_fields = ['id', 'created_at', 'updated_at']
    
    roles = serializers.SerializerMethodField()

    def get_roles(self, obj):
        if not obj.user:
            return []
        from apps.abac.models import UserRole
        from apps.abac.serializers import RoleSerializer
        user_roles = UserRole.objects.filter(user=obj.user, is_active=True).select_related('role')
        return RoleSerializer([ur.role for ur in user_roles], many=True).data
    
    def get_direct_reports_count(self, obj):
        return obj.direct_reports.filter(is_active=True).count()


class EmployeeCreateSerializer(serializers.ModelSerializer):
    """Serializer for creating new employees"""
    
    email = serializers.EmailField()
    first_name = serializers.CharField(max_length=50)
    last_name = serializers.CharField(max_length=50)
    phone = serializers.CharField(max_length=15, required=False, allow_blank=True)
    password = serializers.CharField(write_only=True, required=False)
    
    department_id = serializers.UUIDField(required=False, allow_null=True)
    designation_id = serializers.UUIDField(required=False, allow_null=True)
    location_id = serializers.UUIDField(required=False, allow_null=True)
    reporting_manager_id = serializers.UUIDField(required=False, allow_null=True)
    
    class Meta:
        model = Employee
        fields = [
            'email', 'first_name', 'last_name', 'phone', 'password',
            'employee_id', 'date_of_joining', 'employment_type',
            'department_id', 'designation_id', 'location_id', 'reporting_manager_id',
            'work_mode', 'gender', 'date_of_birth', 'marital_status', 'blood_group',
            'pan_number', 'aadhaar_number', 'uan_number', 'pf_number', 'esi_number',
            'role_ids'
        ]
    
    role_ids = serializers.ListField(
        child=serializers.UUIDField(),
        write_only=True,
        required=False,
        default=list
    )

    def create(self, validated_data):
        role_ids = validated_data.pop('role_ids', [])
        # We need to handle User creation here or ensure it's handled by the viewset/manager
        # Assuming the viewset calls this. But Employee.objects.create_employee usually handles User.
        return super().create(validated_data)
    
    def validate_email(self, value):
        from apps.authentication.models import User
        if User.objects.filter(email=value).exists():
            raise serializers.ValidationError("User with this email already exists.")
        return value
    
    def validate_employee_id(self, value):
        if Employee.objects.filter(employee_id=value).exists():
            raise serializers.ValidationError("Employee ID already exists.")
        return value


class EmployeeUpdateSerializer(serializers.ModelSerializer):
    """Serializer for updating employees"""
    
    class Meta:
        model = Employee
        fields = [
            'date_of_birth', 'gender', 'marital_status', 'blood_group', 'nationality',
            'department', 'designation', 'location',
            'reporting_manager', 'hr_manager',
            'employment_type', 'employment_status',
            'confirmation_date', 'probation_end_date', 'notice_period_days',
            'work_mode',
            'pan_number', 'aadhaar_number', 'passport_number', 'passport_expiry',
            'uan_number', 'pf_number', 'esi_number',
            'bio', 'linkedin_url', 'is_active', 'role_ids'
        ]
    
    role_ids = serializers.ListField(
        child=serializers.UUIDField(),
        write_only=True,
        required=False,
        default=list
    )


class OrgChartSerializer(serializers.ModelSerializer):
    """Serializer for organization chart"""
    
    full_name = serializers.ReadOnlyField()
    designation_name = serializers.CharField(source='designation.name', read_only=True)
    department_name = serializers.CharField(source='department.name', read_only=True)
    avatar = serializers.ImageField(source='user.avatar', read_only=True)
    children = serializers.SerializerMethodField()
    
    class Meta:
        model = Employee
        fields = [
            'id', 'employee_id', 'full_name', 'avatar',
            'designation_name', 'department_name', 'children'
        ]
    
    def get_children(self, obj):
        children = obj.direct_reports.filter(is_active=True)
        return OrgChartSerializer(children, many=True).data


class EmployeeTransferSerializer(serializers.ModelSerializer):
    """Serializer for employee transfers"""
    employee_name = serializers.CharField(source='employee.full_name', read_only=True)
    from_department_name = serializers.CharField(source='from_department.name', read_only=True)
    to_department_name = serializers.CharField(source='to_department.name', read_only=True)
    from_location_name = serializers.CharField(source='from_location.name', read_only=True)
    to_location_name = serializers.CharField(source='to_location.name', read_only=True)
    from_manager_name = serializers.CharField(source='from_manager.full_name', read_only=True)
    to_manager_name = serializers.CharField(source='to_manager.full_name', read_only=True)
    status_display = serializers.CharField(source='get_status_display', read_only=True)
    transfer_type_display = serializers.CharField(source='get_transfer_type_display', read_only=True)

    class Meta:
        model = EmployeeTransfer
        fields = '__all__'
        read_only_fields = ['id', 'status', 'initiated_by', 'approved_by', 'approved_at', 'created_at', 'updated_at']


class EmployeePromotionSerializer(serializers.ModelSerializer):
    """Serializer for employee promotions"""
    employee_name = serializers.CharField(source='employee.full_name', read_only=True)
    from_designation_name = serializers.CharField(source='from_designation.name', read_only=True)
    to_designation_name = serializers.CharField(source='to_designation.name', read_only=True)
    status_display = serializers.CharField(source='get_status_display', read_only=True)

    class Meta:
        model = EmployeePromotion
        fields = '__all__'
        read_only_fields = ['id', 'status', 'recommended_by', 'approved_by', 'approved_at', 'created_at', 'updated_at']


class ResignationRequestSerializer(serializers.ModelSerializer):
    """Serializer for resignation requests"""
    employee_name = serializers.CharField(source='employee.full_name', read_only=True)
    status_display = serializers.CharField(source='get_status_display', read_only=True)
    primary_reason_display = serializers.CharField(source='get_primary_reason_display', read_only=True)

    class Meta:
        model = ResignationRequest
        fields = '__all__'
        read_only_fields = ['id', 'status', 'accepted_by', 'accepted_at', 'created_at', 'updated_at']


class ExitInterviewSerializer(serializers.ModelSerializer):
    """Serializer for exit interviews"""
    employee_name = serializers.CharField(source='employee.full_name', read_only=True)
    interviewer_name = serializers.CharField(source='interviewer.full_name', read_only=True)
    average_rating = serializers.ReadOnlyField()

    class Meta:
        model = ExitInterview
        fields = '__all__'
        read_only_fields = ['id', 'is_completed', 'completed_at', 'created_at', 'updated_at']


class EmployeeBulkImportSerializer(EmployeeCreateSerializer):
    """Serializer for bulk importing employees with User creation handling"""
    
    def create(self, validated_data):
        from django.db import transaction
        from apps.authentication.models import User
        from apps.employees.models import Employee, EmploymentHistory
        import secrets

        # Extract user data
        email = validated_data.pop('email')
        first_name = validated_data.pop('first_name')
        last_name = validated_data.pop('last_name')
        phone = validated_data.pop('phone', '')
        password = validated_data.pop('password', None) or secrets.token_urlsafe(12)
        
        # Extract related fields IDs
        dept_id = validated_data.pop('department_id', None)
        desig_id = validated_data.pop('designation_id', None)
        loc_id = validated_data.pop('location_id', None)
        manager_id = validated_data.pop('reporting_manager_id', None)
        role_ids = validated_data.pop('role_ids', [])

        with transaction.atomic():
            # Create User
            user = User.objects.create_user(
                email=email,
                password=password,
                first_name=first_name,
                last_name=last_name,
                phone=phone
            )

            # Create Employee
            employee = Employee.objects.create(
                user=user,
                department_id=dept_id,
                designation_id=desig_id,
                location_id=loc_id,
                reporting_manager_id=manager_id,
                created_by=self.context['request'].user if 'request' in self.context else None,
                **validated_data
            )
            
            # History
            EmploymentHistory.objects.create(
                employee=employee,
                change_type='joining',
                effective_date=employee.date_of_joining,
                new_department=employee.department,
                new_designation=employee.designation,
                new_location=employee.location,
                new_manager=employee.reporting_manager,
                created_by=self.context['request'].user if 'request' in self.context else None,
            )
            
        return employee


class DepartmentBulkImportSerializer(serializers.ModelSerializer):
    """Serializer for bulk importing departments"""
    
    parent_code = serializers.CharField(required=False, allow_blank=True, write_only=True)
    head_employee_id = serializers.CharField(required=False, allow_blank=True, write_only=True)
    
    class Meta:
        model = Department
        fields = [
            'name', 'code', 'description', 'parent_code',
            'head_employee_id', 'cost_center'
        ]
        
    def create(self, validated_data):
        parent_code = validated_data.pop('parent_code', None)
        head_employee_id = validated_data.pop('head_employee_id', None)
        
        # Resolve parent
        parent = None
        if parent_code:
            try:
                parent = Department.objects.get(code=parent_code)
            except Department.DoesNotExist:
                raise serializers.ValidationError(f"Parent department with code '{parent_code}' not found.")
                
        # Resolve head
        head = None
        if head_employee_id:
            try:
                head = Employee.objects.get(employee_id=head_employee_id)
            except Employee.DoesNotExist:
                raise serializers.ValidationError(f"Employee with ID '{head_employee_id}' not found.")
                
        return Department.objects.create(
            parent=parent,
            head=head,
            **validated_data
        )


class DesignationBulkImportSerializer(serializers.ModelSerializer):
    """Serializer for bulk importing designations"""
    
    class Meta:
        model = Designation
        fields = [
            'name', 'code', 'description', 'level',
            'grade', 'job_family', 'min_salary', 'max_salary'
        ]
