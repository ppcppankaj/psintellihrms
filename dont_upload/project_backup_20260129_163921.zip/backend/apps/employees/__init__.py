"""Employees app initialization"""
default_app_config = 'apps.employees.apps.EmployeesConfig'
