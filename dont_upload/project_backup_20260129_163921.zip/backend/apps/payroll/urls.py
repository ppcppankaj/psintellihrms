"""
Payroll URLs
"""

from django.urls import path, include
from rest_framework.routers import DefaultRouter

from .views import (
    EmployeeCompensationViewSet, PayrollRunViewSet, PayslipViewSet,
    TaxDeclarationViewSet, ReimbursementClaimViewSet
)

router = DefaultRouter()
# router.register(r'components', SalaryComponentViewSet) # REMOVED
# router.register(r'structures', SalaryStructureViewSet) # REMOVED
router.register(r'compensations', EmployeeCompensationViewSet) # Uses EmployeeSalary model now
router.register(r'runs', PayrollRunViewSet)
router.register(r'payslips', PayslipViewSet)
router.register(r'tax-declarations', TaxDeclarationViewSet)
router.register(r'reimbursements', ReimbursementClaimViewSet)

urlpatterns = [
    path('', include(router.urls)),
]
