"""
Payroll Serializers
"""

from rest_framework import serializers
from .models import (
    EmployeeSalary, PayrollRun, Payslip, TaxDeclaration, ReimbursementClaim
)
from apps.employees.serializers import EmployeeListSerializer

class EmployeeSalarySerializer(serializers.ModelSerializer):
    """
    Handles Flat Salary Model.
    Maps 'components' JSON array <-> Flat Database Fields.
    """
    employee_details = EmployeeListSerializer(source='employee', read_only=True)
    
    # Frontend sends/expects 'components' array
    components = serializers.ListField(child=serializers.DictField(), required=False, write_only=True)
    
    class Meta:
        model = EmployeeSalary
        fields = [
            'id', 'employee', 'employee_details', 
            'effective_from', 'effective_to', 'is_active',
            'annual_ctc', 'monthly_gross', 'net_salary', 'total_deductions',
            'components', # Virtual field for I/O
            # Earnings
            'basic', 'hra', 'da', 'special_allowance', 'conveyance', 'medical_allowance', 'lta',
            'other_allowances', 'performance_bonus', 'variable_pay', 'arrears',
            # Deductions
            'pf_employee', 'esi_employee', 'professional_tax', 'tds', 'other_deductions',
            # Contributions
            'pf_employer', 'esi_employer', 'gratuity'
        ]

    def to_representation(self, instance):
        """Convert flat fields to 'components' array for Frontend UI"""
        data = super().to_representation(instance)
        
        components = []
        
        # Helper to create component dict
        def add_component(code, name, c_type, amount):
            if amount > 0 or code in ['BASIC', 'HRA', 'PF_EMPLOYEE']:
                 components.append({
                    'component_code': code,
                    'component_name': name,
                    'type': c_type,
                    'monthly_amount': float(amount or 0),
                    'annual_amount': float(amount or 0) * 12
                })

        # Dynamically map fields based on model attributes
        # Earnings
        add_component('BASIC', 'Basic Salary', 'earning', instance.basic)
        add_component('HRA', 'House Rent Allowance (HRA)', 'earning', instance.hra)
        add_component('DA', 'Dearness Allowance (DA)', 'earning', instance.da)
        add_component('SPECIAL', 'Special Allowance', 'earning', instance.special_allowance)
        add_component('CONVEYANCE', 'Conveyance Allowance', 'earning', instance.conveyance)
        add_component('MEDICAL', 'Medical Allowance', 'earning', instance.medical_allowance)
        add_component('LTA', 'Leave Travel Allowance (LTA)', 'earning', instance.lta)
        add_component('OTHER_ALLOW', 'Other Allowances', 'earning', instance.other_allowances)
        
        # Bonuses
        add_component('BONUS', 'Performance Bonus', 'earning', instance.performance_bonus)
        add_component('VARIABLE', 'Variable Pay', 'earning', instance.variable_pay)
        add_component('ARREARS', 'Arrears', 'earning', instance.arrears)

        # Deductions
        add_component('PF_EMPLOYEE', 'PF (Employee)', 'deduction', instance.pf_employee)
        add_component('ESI_EMPLOYEE', 'ESI (Employee)', 'deduction', instance.esi_employee)
        add_component('PROF_TAX', 'Professional Tax', 'deduction', instance.professional_tax)
        add_component('TDS', 'TDS (Income Tax)', 'deduction', instance.tds)
        add_component('OTHER_DEDUCT', 'Other Deductions', 'deduction', instance.other_deductions)

        # Statutory
        add_component('PF_EMPLOYER', 'PF (Employer)', 'statutory', instance.pf_employer)
        add_component('ESI_EMPLOYER', 'ESI (Employer)', 'statutory', instance.esi_employer)
        add_component('GRATUITY', 'Gratuity', 'statutory', instance.gratuity)
        
        data['components'] = components
        return data

    def create(self, validated_data):
        components_data = validated_data.pop('components', [])
        return self._save_salary(validated_data, components_data)

    def update(self, instance, validated_data):
        components_data = validated_data.pop('components', [])
        
        # Update standard fields first
        for attr, value in validated_data.items():
            setattr(instance, attr, value)
            
        return self._save_salary(instance, components_data, is_update=True)

    def _save_salary(self, data_or_instance, components_data, is_update=False):
        """Helper to map component list back to flat fields"""
        
        # Valid code map
        # Valid code map
        code_map = {
            'BASIC': 'basic', 'HRA': 'hra', 'DA': 'da',
            'SPECIAL': 'special_allowance', 'CONVEYANCE': 'conveyance',
            'MEDICAL': 'medical_allowance', 'LTA': 'lta',
            'OTHER_ALLOW': 'other_allowances',
            
            'BONUS': 'performance_bonus', 
            'VARIABLE': 'variable_pay',
            'ARREARS': 'arrears',
            
            'PF_EMPLOYEE': 'pf_employee', 'ESI_EMPLOYEE': 'esi_employee',
            'PROF_TAX': 'professional_tax', 'TDS': 'tds',
            'OTHER_DEDUCT': 'other_deductions',
            
            'PF_EMPLOYER': 'pf_employer', 'ESI_EMPLOYER': 'esi_employer',
            'GRATUITY': 'gratuity',
        }

        # Extract values from components list
        flat_values = {}
        
        # Separate breakdown for JSON fields
        earnings_breakup = {}
        deductions_breakup = {}

        # Validation: check for valid codes
        for comp in components_data:
            code = comp.get('component_code_input') or comp.get('component_code')
            if not code:
                continue # Skip empty rows
                
            field_name = code_map.get(code)
            if not field_name:
                continue

            try:
                from decimal import Decimal
                amount = Decimal(str(comp.get('monthly_amount', 0)))
                flat_values[field_name] = amount
                
                # Categorize for JSON
                # Heuristic: Check if field name contains 'deduction', 'pf', 'esi', 'tax', 'fund', 'recovery'
                # Better: Use the code map or hardcoded lists
                if code in ['PF_EMPLOYEE', 'ESI_EMPLOYEE', 'PROF_TAX', 'TDS', 'LWF', 'LOAN', 'ADVANCE', 'OTHER_DEDUCT']:
                    deductions_breakup[code] = float(amount) # JSON fields prefer float/str, Decimal not JSON serializable by default without encoder
                elif code in ['PF_EMPLOYER', 'ESI_EMPLOYER', 'GRATUITY', 'SUPERANNUATION', 'NPS', 'INSURANCE']:
                    # Statutory/Employer deductions often kept separate or in deductions depending on context
                    # For now put in deductions_breakup or ignore if purely employer side (not part of net pay calc typically, but ctC)
                    pass
                else:
                    earnings_breakup[code] = float(amount)

            except (ValueError, TypeError):
                 raise serializers.ValidationError({
                    'components': f"Invalid amount for component {code}"
                })



        if is_update:
            instance = data_or_instance
            for field, val in flat_values.items():
                setattr(instance, field, val)
            instance.save()
            return instance
        else:
            # Create
            # Merge flat values into initial data
            final_data = {**data_or_instance, **flat_values}
            return EmployeeSalary.objects.create(**final_data)

class PayrollRunSerializer(serializers.ModelSerializer):
    status_display = serializers.CharField(source='get_status_display', read_only=True)
    
    class Meta:
        model = PayrollRun
        fields = '__all__'

class PayslipSerializer(serializers.ModelSerializer):
    employee_details = EmployeeListSerializer(source='employee', read_only=True)
    payroll_run_details = PayrollRunSerializer(source='payroll_run', read_only=True)
    
    class Meta:
        model = Payslip
        fields = '__all__'

class PayslipListSerializer(serializers.ModelSerializer):
    employee_name = serializers.SerializerMethodField()
    employee_id = serializers.ReadOnlyField(source='employee.employee_id')
    
    class Meta:
        model = Payslip
        fields = [
            'id', 'employee_id', 'employee_name', 'gross_salary', 
            'total_deductions', 'net_salary', 'pdf_file'
        ]
        
    def get_employee_name(self, obj):
        return f"{obj.employee.first_name} {obj.employee.last_name}"

class TaxDeclarationSerializer(serializers.ModelSerializer):
    employee_name = serializers.ReadOnlyField(source='employee.user.full_name')
    
    class Meta:
        model = TaxDeclaration
        fields = '__all__'


class ReimbursementClaimSerializer(serializers.ModelSerializer):
    """Serializer for ReimbursementClaim model"""
    employee_name = serializers.ReadOnlyField(source='employee.user.full_name')
    employee_id = serializers.ReadOnlyField(source='employee.employee_id')
    
    class Meta:
        model = ReimbursementClaim
        fields = [
            'id', 'employee', 'employee_id', 'employee_name',
            'title', 'amount', 'description', 'bill',
            'status', 'submitted_at', 'approved_at', 'paid_at',
            'created_at', 'updated_at'
        ]
        read_only_fields = ['submitted_at', 'approved_at', 'paid_at']


class ReimbursementClaimListSerializer(serializers.ModelSerializer):
    """Light serializer for list views"""
    employee_name = serializers.ReadOnlyField(source='employee.user.full_name')
    
    class Meta:
        model = ReimbursementClaim
        fields = ['id', 'employee_name', 'title', 'amount', 'status', 'submitted_at']
