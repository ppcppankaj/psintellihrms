from celery import shared_task, group
from django.db import transaction
from django.utils import timezone
from .models import PayrollRun, Payslip
from apps.employees.models import Employee
from .services import PayrollCalculationService

@shared_task(bind=True, max_retries=3)
def calculate_single_payslip_task(self, employee_id, payroll_run_id):
    """
    Task to calculate payslip for a single employee.
    """
    try:
        employee = Employee.objects.get(id=employee_id)
        payroll_run = PayrollRun.objects.get(id=payroll_run_id)
        
        # We calculate the payslip. The service handles update_or_create.
        PayrollCalculationService.calculate_payslip(employee, payroll_run)
        return True
    except Exception as exc:
        # Log error or retry
        self.retry(exc=exc, countdown=5)
        return False

@shared_task
def finalize_payroll_run_task(results, payroll_run_id):
    """
    Callback task to finalize the payroll run once all individual tasks are done.
    """
    from decimal import Decimal
    payroll_run = PayrollRun.objects.get(id=payroll_run_id)
    
    # Aggregate results
    payslips = Payslip.objects.filter(payroll_run=payroll_run)
    
    total_employees = payslips.count()
    total_gross = sum(p.gross_salary for p in payslips)
    total_deductions = sum(p.total_deductions for p in payslips)
    total_net = sum(p.net_salary for p in payslips)
    
    payroll_run.total_employees = total_employees
    payroll_run.total_gross = total_gross
    payroll_run.total_deductions = total_deductions
    payroll_run.total_net = total_net
    payroll_run.status = PayrollRun.STATUS_PROCESSED
    payroll_run.processed_at = timezone.now()
    payroll_run.save()
    
    return f"Payroll Run {payroll_run_id} finalized."
