"""
Payroll ViewSets
Security: Requires authentication and branch-level isolation
"""

from rest_framework import viewsets, status, filters
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django.utils import timezone
from django.db.models import Q
from django.http import FileResponse
from django_filters.rest_framework import DjangoFilterBackend

from .models import (
    EmployeeSalary,
    PayrollRun, Payslip, TaxDeclaration, ReimbursementClaim
)
from .serializers import (
    EmployeeSalarySerializer, PayrollRunSerializer,
    PayslipSerializer, PayslipListSerializer, TaxDeclarationSerializer,
    ReimbursementClaimSerializer, ReimbursementClaimListSerializer
)
from .services import PayrollCalculationService

from apps.core.tenant_guards import OrganizationViewSetMixin
from apps.core.permissions_branch import BranchFilterBackend, BranchPermission


class BranchFilterMixin:
    """Mixin to add branch filtering to payroll viewsets"""
    
    def get_branch_ids(self):
        """Get branch IDs for current user"""
        if self.request.user.is_superuser:
            return None  # No filter
        
        from apps.authentication.models_hierarchy import BranchUser
        return list(BranchUser.objects.filter(
            user=self.request.user,
            is_active=True
        ).values_list('branch_id', flat=True))


# Note: SalaryComponentViewSet and SalaryStructureViewSet are REMOVED as tables are deleted.

class EmployeeCompensationViewSet(BranchFilterMixin, OrganizationViewSetMixin, viewsets.ModelViewSet):
    """
    Manages Employee Salary Structures.
    Branch-scoped through employee relationship.
    """
    queryset = EmployeeSalary.objects.select_related('employee', 'employee__user').all()
    serializer_class = EmployeeSalarySerializer
    permission_classes = [IsAuthenticated, BranchPermission]
    filter_backends = [BranchFilterBackend, DjangoFilterBackend, filters.SearchFilter]
    filterset_fields = ['employee']
    
    def get_queryset(self):
        """Filter by user's accessible branches"""
        queryset = super().get_queryset()
        branch_ids = self.get_branch_ids()
        
        if branch_ids is None:
            return queryset
        
        if not branch_ids:
            return queryset.none()
        
        return queryset.filter(employee__branch_id__in=branch_ids)
    
    def create(self, request, *args, **kwargs):
        """
        Handle creation of salary structure.
        Implements UPSERT logic: If structure exists for employee, update it.
        """
        try:
            employee_id = request.data.get('employee')
            
            # Standard creation if no employee_id (let validator handle)
            if not employee_id:
                return super().create(request, *args, **kwargs)
                
            # Check for existing record including soft-deleted ones
            # EmployeeSalary uses SoftDeleteManager, so default objects.get() misses deleted ones.
            # Using all_with_deleted() to find potential conflicts.
            # Note: We filter() then first() to avoid MultipleObjectsReturned (though OneToOne prevents duplicates usually)
            instance = EmployeeSalary.objects.all_with_deleted().filter(employee=employee_id).first()
            
            if instance:
                # If found, check if it's soft-deleted
                if getattr(instance, 'is_deleted', False):
                    instance.restore() # Restore soft-deleted record
                
                # Perform update
                serializer = self.get_serializer(instance, data=request.data)
                serializer.is_valid(raise_exception=True)
                self.perform_update(serializer)
                return Response(serializer.data)
            
            else:
                # If genuinely not exists, create new
                serializer = self.get_serializer(data=request.data)
                serializer.is_valid(raise_exception=True)
                serializer.save()
                headers = self.get_success_headers(serializer.data)
                return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)

        except Exception as e:
            # Capture full traceback for debugging
            import traceback
            error_details = traceback.format_exc()
            print(f"CRITICAL ERROR IN SALARY SAVE: {error_details}")
            return Response(
                {"error": str(e), "traceback": error_details}, 
                status=status.HTTP_400_BAD_REQUEST
            )

    @action(detail=False, methods=['post'], url_path='calculate-structure')
    def calculate_structure(self, request):
        """Calculate salary structure breakdown based on CTC"""
        annual_ctc = request.data.get('annual_ctc')
        if not annual_ctc:
            return Response({"error": "Annual CTC is required"}, status=status.HTTP_400_BAD_REQUEST)
        
        try:
            from .services import SalaryStructureService
            breakdown = SalaryStructureService.calculate_breakdown(annual_ctc)
            return Response(breakdown)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=False, methods=['get'], url_path='my-compensation')
    def my_compensation(self, request):
        """Get current compensation for the logged-in employee"""
        if not hasattr(request.user, 'employee'):
            return Response({"error": "No employee profile found"}, status=404)
            
        # OneToOne, so simple access
        try:
            salary = request.user.employee.salary # Related name 'salary'
        except EmployeeSalary.DoesNotExist:
            return Response({"error": "No active compensation found"}, status=404)
            
        serializer = self.get_serializer(salary)
        return Response(serializer.data)


class PayrollRunViewSet(BranchFilterMixin, OrganizationViewSetMixin, viewsets.ModelViewSet):
    """
    Payroll run management.
    Branch-scoped - each payroll run belongs to a branch.
    """
    queryset = PayrollRun.objects.all()
    serializer_class = PayrollRunSerializer
    permission_classes = [IsAuthenticated, BranchPermission]
    filter_backends = [BranchFilterBackend, DjangoFilterBackend, filters.SearchFilter]
    filterset_fields = ['status', 'month', 'year', 'branch']
    
    def get_queryset(self):
        """Filter by user's accessible branches"""
        queryset = super().get_queryset()
        branch_ids = self.get_branch_ids()
        
        if branch_ids is None:
            return queryset
        
        if not branch_ids:
            return queryset.none()
        
        return queryset.filter(branch_id__in=branch_ids)
    
    @action(detail=True, methods=['post'])
    def process(self, request, pk=None):
        """Process payroll for all employees in this run"""
        payroll_run = self.get_object()
        if payroll_run.status not in [PayrollRun.STATUS_DRAFT, PayrollRun.STATUS_PROCESSING]:
            return Response(
                {"error": "Payroll run is not in a processable state"},
                status=status.HTTP_400_BAD_REQUEST
            )
            
        payroll_run = PayrollCalculationService.process_payroll_run(payroll_run.id)
        serializer = self.get_serializer(payroll_run)
        return Response(serializer.data)
        
    @action(detail=True, methods=['post'])
    def approve(self, request, pk=None):
        """Approve a processed payroll run"""
        payroll_run = self.get_object()
        if payroll_run.status != PayrollRun.STATUS_PROCESSED:
            return Response(
                {"error": "Only processed payroll runs can be approved"},
                status=status.HTTP_400_BAD_REQUEST
            )
            
        payroll_run.status = PayrollRun.STATUS_APPROVED
        payroll_run.approved_at = timezone.now()
        # Set approved_by from current user
        if hasattr(request.user, 'employee'):
            payroll_run.approved_by = request.user.employee
        payroll_run.save()
        
        serializer = self.get_serializer(payroll_run)
        return Response(serializer.data)


class PayslipViewSet(BranchFilterMixin, OrganizationViewSetMixin, viewsets.ReadOnlyModelViewSet):
    """
    Payslip viewing.
    Branch-scoped through employee relationship.
    """
    queryset = Payslip.objects.all()
    permission_classes = [IsAuthenticated, BranchPermission]
    filter_backends = [BranchFilterBackend, DjangoFilterBackend]
    filterset_fields = ['payroll_run', 'employee']
    
    def get_queryset(self):
        """Filter by user's accessible branches"""
        queryset = super().get_queryset()
        branch_ids = self.get_branch_ids()
        
        if branch_ids is None:
            return queryset
        
        if not branch_ids:
            return queryset.none()
        
        return queryset.filter(employee__branch_id__in=branch_ids)
    
    def get_serializer_class(self):
        if self.action == 'list':
            return PayslipListSerializer
        return PayslipSerializer

    @action(detail=False, methods=['get'])
    def summary(self, request):
        """Get payroll summary for dashboard using efficient DB aggregation"""
        employee = getattr(request.user, 'employee', None)
        if not employee:
            return Response({"error": "No employee record found"}, status=404)
            
        now = timezone.now()
        current_year = now.year
        current_month = now.month
        
        latest_payslip = self.get_queryset().filter(
            employee=employee,
            payroll_run__status='paid'
        ).order_by('-payroll_run__year', '-payroll_run__month').first()
        
        current_net = latest_payslip.net_salary if latest_payslip else 0
        last_salary_date = latest_payslip.payroll_run.pay_date if latest_payslip else None
        
        # YTD Gross & Tax (Financial Year: April to March)
        if current_month >= 4:
            fy_start_year = current_year
        else:
            fy_start_year = current_year - 1
            
        from django.db.models import Sum
        
        ytd_stats = self.get_queryset().filter(
            employee=employee,
            payroll_run__status='paid'
        ).filter(
            Q(payroll_run__year=fy_start_year, payroll_run__month__gte=4) | 
            Q(payroll_run__year=fy_start_year + 1, payroll_run__month__lte=3)
        ).aggregate(
            total_gross=Sum('gross_salary'),
            total_tax=Sum('tds')
        )
        
        ytd_gross = ytd_stats['total_gross'] or 0
        ytd_tax = ytd_stats['total_tax'] or 0
        
        # Pending Reimbursements
        pending_amount = 0
        try:
            from apps.expenses.models import Expense
            pending_stats = Expense.objects.filter(
                employee=employee,
                status='approved',
                is_reimbursed=False
            ).aggregate(total=Sum('amount'))
            pending_amount = pending_stats['total'] or 0
        except Exception:
            pending_amount = 0

        return Response({
            "current_month_net": current_net,
            "ytd_gross": ytd_gross,
            "ytd_tax": ytd_tax,
            "pending_reimbursements": pending_amount,
            "last_salary_date": last_salary_date
        })

    @action(detail=True, methods=['get'])
    def download(self, request, pk=None):
        """Download payslip as PDF"""
        payslip = self.get_object()
        
        # Check if user has access to this payslip
        if not request.user.is_superuser:
            if hasattr(request.user, 'employee') and request.user.employee != payslip.employee:
                # Check if user has HR/Manager access to this employee's branch
                branch_ids = self.get_branch_ids()
                if branch_ids and payslip.employee.branch_id not in branch_ids:
                    return Response(
                        {"error": "You don't have access to this payslip"},
                        status=status.HTTP_403_FORBIDDEN
                    )
        
        # Check if PDF file exists
        if payslip.pdf_file and payslip.pdf_file.name:
            try:
                response = FileResponse(
                    payslip.pdf_file.open('rb'),
                    content_type='application/pdf'
                )
                filename = f"payslip_{payslip.employee.employee_id}_{payslip.payroll_run.month}_{payslip.payroll_run.year}.pdf"
                response['Content-Disposition'] = f'attachment; filename="{filename}"'
                return response
            except FileNotFoundError:
                pass
        
        # Generate PDF on-the-fly if not stored
        from .services import PayslipPDFService
        try:
            pdf_content = PayslipPDFService.generate_payslip_pdf(payslip)
            response = Response(pdf_content, content_type='application/pdf')
            filename = f"payslip_{payslip.employee.employee_id}_{payslip.payroll_run.month}_{payslip.payroll_run.year}.pdf"
            response['Content-Disposition'] = f'attachment; filename="{filename}"'
            return response
        except Exception as e:
            return Response(
                {"error": f"Could not generate payslip PDF: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )


class TaxDeclarationViewSet(BranchFilterMixin, OrganizationViewSetMixin, viewsets.ModelViewSet):
    """
    Tax declaration management.
    Branch-scoped through employee relationship.
    """
    queryset = TaxDeclaration.objects.all()
    serializer_class = TaxDeclarationSerializer
    permission_classes = [IsAuthenticated, BranchPermission]
    filter_backends = [BranchFilterBackend, DjangoFilterBackend, filters.SearchFilter]
    filterset_fields = ['employee', 'financial_year', 'proofs_submitted', 'proofs_verified']
    search_fields = ['employee__employee_id', 'employee__user__full_name']
    
    def get_queryset(self):
        """Filter by user's accessible branches"""
        queryset = super().get_queryset()
        branch_ids = self.get_branch_ids()
        
        if branch_ids is None:
            return queryset
        
        if not branch_ids:
            return queryset.none()
        
        return queryset.filter(employee__branch_id__in=branch_ids)


class ReimbursementClaimViewSet(BranchFilterMixin, OrganizationViewSetMixin, viewsets.ModelViewSet):
    """
    Reimbursement claim management.
    Branch-scoped through employee relationship.
    """
    queryset = ReimbursementClaim.objects.select_related('employee', 'employee__user').all()
    serializer_class = ReimbursementClaimSerializer
    permission_classes = [IsAuthenticated, BranchPermission]
    filter_backends = [BranchFilterBackend, DjangoFilterBackend, filters.SearchFilter]
    filterset_fields = ['employee', 'status']
    search_fields = ['title', 'employee__user__full_name']
    
    def get_queryset(self):
        """Filter by user's accessible branches"""
        queryset = super().get_queryset()
        branch_ids = self.get_branch_ids()
        
        if branch_ids is None:
            return queryset
        
        if not branch_ids:
            return queryset.none()
        
        return queryset.filter(employee__branch_id__in=branch_ids)
    
    def get_serializer_class(self):
        if self.action == 'list':
            return ReimbursementClaimListSerializer
        return ReimbursementClaimSerializer
    
    @action(detail=True, methods=['post'])
    def submit(self, request, pk=None):
        """Submit a draft reimbursement claim"""
        claim = self.get_object()
        if claim.status != ReimbursementClaim.STATUS_DRAFT:
            return Response(
                {"error": "Only draft claims can be submitted"},
                status=status.HTTP_400_BAD_REQUEST
            )
        claim.status = ReimbursementClaim.STATUS_SUBMITTED
        claim.submitted_at = timezone.now()
        claim.save()
        return Response(ReimbursementClaimSerializer(claim).data)
    
    @action(detail=True, methods=['post'])
    def approve(self, request, pk=None):
        """Approve a submitted reimbursement claim"""
        claim = self.get_object()
        if claim.status != ReimbursementClaim.STATUS_SUBMITTED:
            return Response(
                {"error": "Only submitted claims can be approved"},
                status=status.HTTP_400_BAD_REQUEST
            )
        claim.status = ReimbursementClaim.STATUS_APPROVED
        claim.approved_at = timezone.now()
        claim.save()
        return Response(ReimbursementClaimSerializer(claim).data)
    
    @action(detail=True, methods=['post'])
    def reject(self, request, pk=None):
        """Reject a submitted reimbursement claim"""
        claim = self.get_object()
        if claim.status != ReimbursementClaim.STATUS_SUBMITTED:
            return Response(
                {"error": "Only submitted claims can be rejected"},
                status=status.HTTP_400_BAD_REQUEST
            )
        claim.status = ReimbursementClaim.STATUS_REJECTED
        claim.save()
        return Response(ReimbursementClaimSerializer(claim).data)
    
    @action(detail=False, methods=['get'], url_path='my-claims')
    def my_claims(self, request):
        """Get current user's reimbursement claims"""
        if not hasattr(request.user, 'employee'):
            return Response({"error": "No employee profile found"}, status=404)
        
        claims = ReimbursementClaim.objects.filter(employee=request.user.employee)
        serializer = ReimbursementClaimListSerializer(claims, many=True)
        return Response(serializer.data)
