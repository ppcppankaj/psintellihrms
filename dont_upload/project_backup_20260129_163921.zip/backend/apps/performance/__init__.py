"""Performance app initialization"""
default_app_config = 'apps.performance.apps.PerformanceConfig'
