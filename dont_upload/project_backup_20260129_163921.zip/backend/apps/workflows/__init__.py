"""Workflows app - Drag & Drop Workflow Engine"""
default_app_config = 'apps.workflows.apps.WorkflowsConfig'
