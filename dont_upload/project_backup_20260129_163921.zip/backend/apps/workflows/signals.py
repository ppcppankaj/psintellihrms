"""
Workflow Signals - Integration with other modules
"""

from django.db.models.signals import post_save
from django.dispatch import receiver
from apps.leave.models import LeaveRequest
from .services import WorkflowService

@receiver(post_save, sender=LeaveRequest)
def trigger_leave_workflow(sender, instance, created, **kwargs):
    """
    Automatically start a workflow instance when a new leave request is created.
    """
    if created:
        # Code 'LEAVE_REQUEST' must exist in WorkflowDefinition
        WorkflowService.start_workflow(
            entity=instance,
            workflow_code='LEAVE_REQUEST',
            initiator=instance.employee
        )
