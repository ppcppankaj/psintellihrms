"""
Workflow Services - Core Approval Engine Logic
"""

from django.utils import timezone
from django.db import transaction
from django.contrib.contenttypes.models import ContentType
from .models import WorkflowDefinition, WorkflowStep, WorkflowInstance, WorkflowAction
from apps.employees.models import Employee

class WorkflowService:
    """
    Service to manage workflow lifecycles, transitions, and actions.
    """

    @staticmethod
    def start_workflow(entity, workflow_code, initiator=None):
        """
        Initialize a workflow instance for a given entity.
        """
        try:
            definition = WorkflowDefinition.objects.get(code=workflow_code)
        except WorkflowDefinition.DoesNotExist:
            return None

        # Get first step
        first_step = definition.workflow_steps.filter(order=1).first()
        if not first_step:
            return None

        # Determine initial approver
        approver = WorkflowService.get_approver_for_step(first_step, entity, initiator)

        instance = WorkflowInstance.objects.create(
            workflow=definition,
            entity_type=entity._meta.model_name,
            entity_id=entity.id,
            current_step=1,
            status='in_progress',
            current_approver=approver,
            organization=entity.organization  # Ensure organization is preserved
        )
        return instance

    @staticmethod
    def get_approver_for_step(step, entity, initiator=None):
        """
        Logic to resolve the specific employee who should approve a step.
        """
        if step.approver_type == 'reporting_manager':
            # Assuming entity has an 'employee' field (like LeaveRequest)
            employee = getattr(entity, 'employee', None)
            if employee and employee.reporting_manager:
                return employee.reporting_manager
        
        elif step.approver_type == 'hr_manager':
            employee = getattr(entity, 'employee', None)
            if employee and employee.hr_manager:
                return employee.hr_manager
                
        elif step.approver_type == 'user':
            return step.approver_user
            
        elif step.approver_type == 'role':
            # Simple implementation: pick first employee with this role in the same department
            # Real implementation might be more complex
            employee = getattr(entity, 'employee', None)
            if employee:
                approver = Employee.objects.filter(
                    user__roles=step.approver_role,
                    department=employee.department,
                    is_active=True
                ).first()
                return approver

        return None

    @staticmethod
    @transaction.atomic
    def take_action(instance, actor, action, comments=''):
        """
        Record an action (Approve/Reject) and transition the workflow.
        """
        if instance.status != 'in_progress':
            raise ValueError("Workflow instance is not in progress.")

        # Record the action
        WorkflowAction.objects.create(
            instance=instance,
            step=instance.current_step,
            actor=actor,
            action=action,
            comments=comments,
            organization=instance.organization
        )

        if action == 'rejected':
            instance.status = 'rejected'
            instance.completed_at = timezone.now()
            instance.save()
            # Callback to entity could be added here
            return instance

        # Move to next step
        next_step = instance.workflow.workflow_steps.filter(order=instance.current_step + 1).first()
        
        if next_step:
            instance.current_step += 1
            instance.current_approver = WorkflowService.get_approver_for_step(
                next_step, 
                # In real app, we'd fetch the actual entity object here
                None, 
                actor
            )
            instance.save()
        else:
            # No more steps - Mark as Approved
            instance.status = 'approved'
            instance.completed_at = timezone.now()
            instance.current_approver = None
            instance.save()
            
        return instance
