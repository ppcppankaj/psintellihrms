"""Workflows URLs"""
from django.urls import path, include
from rest_framework.routers import DefaultRouter

from .views import WorkflowDefinitionViewSet, WorkflowInstanceViewSet, WorkflowStepViewSet

router = DefaultRouter()
router.register(r'definitions', WorkflowDefinitionViewSet)
router.register(r'steps', WorkflowStepViewSet)
router.register(r'instances', WorkflowInstanceViewSet)

urlpatterns = [
    path('', include(router.urls)),
]
