"""Compliance app"""
default_app_config = 'apps.compliance.apps.ComplianceConfig'
