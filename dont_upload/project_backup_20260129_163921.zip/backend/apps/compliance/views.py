"""
Compliance ViewSets - GDPR, Data Retention, Legal Holds
Security: Requires authentication and organization/branch isolation
"""

from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.filters import SearchFilter

from apps.core.permissions_branch import BranchFilterBackend, BranchPermission, OrganizationFilterBackend
from .models import DataRetentionPolicy, ConsentRecord, LegalHold
from .serializers import DataRetentionPolicySerializer, ConsentRecordSerializer, LegalHoldSerializer


class DataRetentionPolicyViewSet(viewsets.ModelViewSet):
    """
    Data Retention Policy management.
    Organization-scoped (policies apply to entire organization).
    """
    queryset = DataRetentionPolicy.objects.all()
    serializer_class = DataRetentionPolicySerializer
    permission_classes = [IsAuthenticated]
    filter_backends = [OrganizationFilterBackend, DjangoFilterBackend, SearchFilter]
    search_fields = ['data_type', 'description']
    
    def get_queryset(self):
        """Filter by user's organization"""
        queryset = super().get_queryset()
        if self.request.user.is_superuser:
            return queryset
        
        org = self.request.user.get_organization()
        if not org:
            return queryset.none()
        
        if hasattr(queryset.model, 'organization'):
            return queryset.filter(organization=org)
        return queryset


class ConsentRecordViewSet(viewsets.ModelViewSet):
    """
    Consent records for GDPR compliance.
    Branch-scoped through employee relationship.
    """
    queryset = ConsentRecord.objects.all()
    serializer_class = ConsentRecordSerializer
    permission_classes = [IsAuthenticated, BranchPermission]
    filter_backends = [BranchFilterBackend, DjangoFilterBackend, SearchFilter]
    filterset_fields = ['employee', 'granted', 'consent_type']
    search_fields = ['consent_type', 'description']
    
    def get_queryset(self):
        """Filter by user's accessible branches via employee"""
        queryset = super().get_queryset()
        if self.request.user.is_superuser:
            return queryset
        
        # Get user's branches
        from apps.authentication.models_hierarchy import BranchUser
        branch_ids = list(BranchUser.objects.filter(
            user=self.request.user,
            is_active=True
        ).values_list('branch_id', flat=True))
        
        if not branch_ids:
            return queryset.none()
        
        return queryset.filter(employee__branch_id__in=branch_ids)


class LegalHoldViewSet(viewsets.ModelViewSet):
    """
    Legal holds for data preservation.
    Organization-scoped with employee references.
    """
    queryset = LegalHold.objects.all()
    serializer_class = LegalHoldSerializer
    permission_classes = [IsAuthenticated, BranchPermission]
    filter_backends = [DjangoFilterBackend, SearchFilter]
    filterset_fields = ['is_active', 'created_at']
    search_fields = ['hold_name', 'description', 'legal_reference']
    
    def get_queryset(self):
        """Filter by user's accessible branches via affected employees"""
        queryset = super().get_queryset()
        if self.request.user.is_superuser:
            return queryset
        
        # Get user's organization
        org = self.request.user.get_organization()
        if not org:
            return queryset.none()
        
        # Filter to legal holds that have affected employees in user's branches
        from apps.authentication.models_hierarchy import BranchUser
        branch_ids = list(BranchUser.objects.filter(
            user=self.request.user,
            is_active=True
        ).values_list('branch_id', flat=True))
        
        if self.request.user.is_org_admin:
            # Org admins see all legal holds in their org
            return queryset.filter(affected_employees__branch__organization=org).distinct()
        
        if not branch_ids:
            return queryset.none()
        
        return queryset.filter(affected_employees__branch_id__in=branch_ids).distinct()
