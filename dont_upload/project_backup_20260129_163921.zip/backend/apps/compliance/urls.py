"""Compliance URLs"""
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import DataRetentionPolicyViewSet, ConsentRecordViewSet, LegalHoldViewSet

router = DefaultRouter()
router.register(r'retention', DataRetentionPolicyViewSet)
router.register(r'consents', ConsentRecordViewSet)
router.register(r'legal-holds', LegalHoldViewSet)

urlpatterns = [
    path('', include(router.urls)),
]
