"""
Compliance Serializers
"""

from rest_framework import serializers
from .models import DataRetentionPolicy, ConsentRecord, LegalHold

class DataRetentionPolicySerializer(serializers.ModelSerializer):
    class Meta:
        model = DataRetentionPolicy
        fields = '__all__'

class ConsentRecordSerializer(serializers.ModelSerializer):
    class Meta:
        model = ConsentRecord
        fields = '__all__'

class LegalHoldSerializer(serializers.ModelSerializer):
    class Meta:
        model = LegalHold
        fields = '__all__'
