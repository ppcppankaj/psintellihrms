"""Compliance Models"""
from django.db import models
from apps.core.models import OrganizationEntity

class DataRetentionPolicy(OrganizationEntity):
    name = models.CharField(max_length=100)
    entity_type = models.CharField(max_length=50)
    retention_days = models.PositiveIntegerField()
    action = models.CharField(max_length=20, choices=[('archive', 'Archive'), ('delete', 'Delete'), ('anonymize', 'Anonymize')])
    
    def __str__(self):
        return f"{self.name} - {self.retention_days} days"

class ConsentRecord(OrganizationEntity):
    employee = models.ForeignKey('employees.Employee', on_delete=models.CASCADE, related_name='consents')
    consent_type = models.CharField(max_length=50)
    granted = models.BooleanField(default=False)
    granted_at = models.DateTimeField(null=True, blank=True)
    revoked_at = models.DateTimeField(null=True, blank=True)
    ip_address = models.GenericIPAddressField(null=True, blank=True)
    
    def __str__(self):
        return f"{self.employee.employee_id} - {self.consent_type}"

class LegalHold(OrganizationEntity):
    name = models.CharField(max_length=100)
    description = models.TextField()
    employees = models.ManyToManyField('employees.Employee', related_name='legal_holds')
    start_date = models.DateField()
    end_date = models.DateField(null=True, blank=True)
    
    def __str__(self):
        return self.name
