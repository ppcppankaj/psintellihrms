"""Compliance Admin"""
from django.contrib import admin
from .models import DataRetentionPolicy, ConsentRecord, LegalHold

@admin.register(DataRetentionPolicy)
class DataRetentionPolicyAdmin(admin.ModelAdmin):
    list_display = ['name', 'entity_type', 'retention_days', 'action', 'is_active']
    list_filter = ['action', 'is_active']

@admin.register(ConsentRecord)
class ConsentRecordAdmin(admin.ModelAdmin):
    list_display = ['employee', 'consent_type', 'granted', 'granted_at', 'revoked_at']
    list_filter = ['consent_type', 'granted']
    raw_id_fields = ['employee']

@admin.register(LegalHold)
class LegalHoldAdmin(admin.ModelAdmin):
    list_display = ['name', 'start_date', 'end_date', 'is_active']
    filter_horizontal = ['employees']
