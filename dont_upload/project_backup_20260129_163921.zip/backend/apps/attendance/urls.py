"""
Attendance URLs
"""

from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import (
    ShiftViewSet, GeoFenceViewSet, AttendanceViewSet, FraudLogViewSet,
    AttendancePunchViewSet
)

router = DefaultRouter()
router.register(r'shifts', ShiftViewSet, basename='shift')
router.register(r'geo-fences', GeoFenceViewSet, basename='geo-fence')
router.register(r'records', AttendanceViewSet, basename='attendance')
router.register(r'punches', AttendancePunchViewSet, basename='punch')
router.register(r'fraud-logs', FraudLogViewSet, basename='fraud-log')

urlpatterns = [
    path('', include(router.urls)),
]
