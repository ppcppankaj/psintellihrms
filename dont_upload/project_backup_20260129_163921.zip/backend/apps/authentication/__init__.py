"""Authentication app initialization"""
default_app_config = 'apps.authentication.apps.AuthenticationConfig'
