"""
Authentication Serializers
"""

from rest_framework import serializers
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from django.contrib.auth import authenticate
from django.contrib.auth.password_validation import validate_password
from .models import User, UserSession


class CustomTokenObtainPairSerializer(TokenObtainPairSerializer):
    """
    Enhanced JWT token serializer with tenant binding.
    SECURITY: Includes organization_id claim to prevent cross-tenant token reuse.
    """
    
    # Override the username field to use email
    email = serializers.CharField(required=True, write_only=True)
    username = None  # Disable the default username field
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Remove the username field if it exists
        if 'username' in self.fields:
            del self.fields['username']
    
    @classmethod
    def get_token(cls, user):
        token = super().get_token(user)
        
        # 🏢 Organization Binding
        # This prevents cross-organization data leakage
        if user.organization:
            org = user.organization
            token['organization_id'] = str(org.id)
            token['organization_name'] = org.name
            token['organization_slug'] = org.slug if hasattr(org, 'slug') else None
        else:
            token['organization_id'] = None
            token['organization_name'] = None
            token['organization_slug'] = 'public'
        
        # Add user claims
        token['email'] = user.email
        token['full_name'] = user.full_name
        token['employee_id'] = user.employee_id
        token['user_id'] = str(user.id)
        
        # ABAC system replaces roles - policies are managed separately
        token['roles'] = []
        
        return token
    
    def validate(self, attrs):
        # Map email to username for parent validation
        email = attrs.get('email')
        password = attrs.get('password')
        
        if not email or not password:
            raise serializers.ValidationError(
                {'detail': 'Must include "email" and "password".'}
            )
        
        # Authenticate using email as username
        user = authenticate(username=email, password=password)
        
        if not user:
            raise serializers.ValidationError(
                {'detail': 'Invalid email or password.'}
            )
        
        # Check if user is locked
        if user.is_locked():
            raise serializers.ValidationError(
                'Account is locked. Please try again later or contact support.'
            )
        
        # Get the token with tenant binding
        refresh = self.get_token(user)
        
        data = {
            'refresh': str(refresh),
            'access': str(refresh.access_token),
        }
        
        return data


class UserSerializer(serializers.ModelSerializer):
    """User serializer for profile"""
    
    full_name = serializers.ReadOnlyField()
    roles = serializers.SerializerMethodField()
    permissions = serializers.SerializerMethodField()
    organization = serializers.SerializerMethodField()
    
    class Meta:
        model = User
        fields = [
            'id', 'email', 'employee_id', 'first_name', 'last_name',
            'middle_name', 'full_name', 'phone', 'avatar', 'date_of_birth',
            'gender', 'is_verified', 'is_2fa_enabled', 'is_superuser', 'is_staff',
            'timezone', 'language', 'roles', 'permissions', 'organization', 'date_joined', 'last_login'
        ]
        read_only_fields = ['id', 'email', 'is_verified', 'is_superuser', 'is_staff', 'date_joined', 'last_login']
    
    def get_roles(self, obj):
        # ABAC system doesn't use roles in the traditional sense
        # Return empty list for now as policies are managed separately
        return []

    def get_permissions(self, obj):
        # ABAC system replaces role-based permissions
        # Return empty list as permissions are managed via policies
        return []

    def get_organization(self, obj):
        organization = obj.organization
        if not organization:
            return None
            
        return {
            'id': str(organization.id),
            'name': organization.name,
            'slug': getattr(organization, 'slug', None),
            'subscription_status': getattr(organization, 'subscription_status', None)
        }


class UserCreateSerializer(serializers.ModelSerializer):
    """Serializer for user registration"""
    
    password = serializers.CharField(write_only=True, validators=[validate_password])
    password_confirm = serializers.CharField(write_only=True)
    
    class Meta:
        model = User
        fields = [
            'email', 'first_name', 'last_name', 'phone',
            'password', 'password_confirm'
        ]
    
    def validate(self, attrs):
        if attrs['password'] != attrs['password_confirm']:
            raise serializers.ValidationError({'password_confirm': 'Passwords do not match.'})
        return attrs
    
    def create(self, validated_data):
        validated_data.pop('password_confirm')
        return User.objects.create_user(**validated_data)


class UserOrgAdminCreateSerializer(serializers.ModelSerializer):
    """
    🔒 SECURITY: Serializer for org admins creating sub-users
    - Org admin can ONLY create users in their organization
    - Org admin CANNOT set is_org_admin, is_staff, or change organization
    - New users are always is_org_admin=False, is_staff=False
    """
    
    password = serializers.CharField(write_only=True, validators=[validate_password])
    password_confirm = serializers.CharField(write_only=True)
    
    class Meta:
        model = User
        fields = [
            'email', 'username', 'first_name', 'last_name', 'phone',
            'password', 'password_confirm', 'is_verified', 'is_active'
        ]
        read_only_fields = ['organization', 'is_org_admin', 'is_staff', 'is_superuser']
    
    def validate_password_confirm(self, value):
        """Ensure passwords match"""
        request = self.context.get('request')
        if not request:
            raise serializers.ValidationError('Request context required')
        return value
    
    def validate(self, attrs):
        """
        🔒 SECURITY validations:
        - Only org admins can create users
        - Passwords must match
        """
        request = self.context.get('request')
        
        if not request or not request.user:
            raise serializers.ValidationError('Authentication required')
        
        # Only org admins can create users
        if not request.user.is_org_admin and not request.user.is_superuser:
            raise serializers.ValidationError(
                'Only organization admins can create users'
            )
        
        # Validate passwords match
        if attrs.get('password') != attrs.get('password_confirm'):
            raise serializers.ValidationError(
                {'password_confirm': 'Passwords do not match.'}
            )
        
        return attrs
    
    def create(self, validated_data):
        """
        🔒 SECURITY: Force organization and prevent privilege escalation
        """
        request = self.context.get('request')
        
        # Remove password_confirm from validated data
        validated_data.pop('password_confirm')
        
        # 🔒 CRITICAL: Force organization to requesting user's org
        # This prevents org hopping or unauthorized org assignment
        if request.user.is_org_admin:
            validated_data['organization'] = request.user.organization
        
        # 🔒 CRITICAL: New users are NEVER org admins or staff
        # Only superusers can grant these privileges
        validated_data['is_org_admin'] = False
        validated_data['is_staff'] = False
        
        return User.objects.create_user(**validated_data)
    
    def update(self, instance, validated_data):
        """
        🔒 Prevent org admin from changing organization
        
        Rules:
        - organization: silently ignored (cannot change)
        - is_org_admin: silently ignored for org admins
        - is_staff: silently ignored for org admins
        """
        request = self.context.get('request')
        
        # 🔒 CRITICAL: Remove organization from any update attempts
        validated_data.pop('organization', None)
        
        # 🔒 CRITICAL: Org admin cannot modify privilege fields
        if request.user and request.user.is_org_admin and not request.user.is_superuser:
            validated_data.pop('is_org_admin', None)
            validated_data.pop('is_staff', None)
            validated_data.pop('is_superuser', None)
        
        return super().update(instance, validated_data)


class UserSelfProfileSerializer(serializers.ModelSerializer):
    """
    🔒 SECURITY: Serializer for users editing their OWN profile
    
    Allowed fields:
    - first_name, last_name, email, password (via separate endpoint)
    - phone, avatar, date_of_birth, gender
    - timezone, language
    
    Hidden/Read-only fields (ALWAYS):
    - organization, is_org_admin, is_staff, is_superuser
    - permissions, groups, is_active, is_verified
    - employee_id, slug
    """
    
    full_name = serializers.ReadOnlyField()
    organization_name = serializers.SerializerMethodField()
    
    class Meta:
        model = User
        fields = [
            'id', 'email', 'first_name', 'last_name', 'middle_name',
            'full_name', 'phone', 'avatar', 'date_of_birth', 'gender',
            'timezone', 'language', 'organization_name', 'date_joined', 'last_login'
        ]
        read_only_fields = [
            'id', 'email', 'full_name', 'organization_name', 'date_joined', 'last_login'
        ]
    
    def get_organization_name(self, obj):
        """Return organization name (read-only)"""
        if obj.organization:
            return obj.organization.name
        return None
    
    def update(self, instance, validated_data):
        """
        🔒 SECURITY: Allow ONLY profile fields
        All other fields are automatically excluded via Meta.fields
        """
        # Double-check to prevent sneaky attempts
        dangerous_fields = [
            'organization', 'is_org_admin', 'is_staff', 'is_superuser',
            'username', 'password', 'employee_id', 'slug', 'is_active',
            'is_verified', 'permissions', 'groups'
        ]
        
        for field in dangerous_fields:
            if field in validated_data:
                validated_data.pop(field, None)
        
        return super().update(instance, validated_data)


class PasswordChangeSerializer(serializers.Serializer):
    """Serializer for password change"""
    
    current_password = serializers.CharField(required=True)
    new_password = serializers.CharField(required=True, validators=[validate_password])
    new_password_confirm = serializers.CharField(required=True)
    
    def validate_current_password(self, value):
        user = self.context['request'].user
        if not user.check_password(value):
            raise serializers.ValidationError('Current password is incorrect.')
        return value
    
    def validate(self, attrs):
        if attrs['new_password'] != attrs['new_password_confirm']:
            raise serializers.ValidationError({'new_password_confirm': 'Passwords do not match.'})
        return attrs


class PasswordResetRequestSerializer(serializers.Serializer):
    """Serializer for password reset request"""
    
    email = serializers.EmailField()


class PasswordResetConfirmSerializer(serializers.Serializer):
    """Serializer for password reset confirmation"""
    
    token = serializers.CharField()
    new_password = serializers.CharField(validators=[validate_password])
    new_password_confirm = serializers.CharField()
    
    def validate(self, attrs):
        if attrs['new_password'] != attrs['new_password_confirm']:
            raise serializers.ValidationError({'new_password_confirm': 'Passwords do not match.'})
        return attrs


class TwoFactorEnableSerializer(serializers.Serializer):
    """Serializer for enabling 2FA"""
    
    password = serializers.CharField(required=True)


class TwoFactorVerifySerializer(serializers.Serializer):
    """Serializer for verifying 2FA code"""
    
    code = serializers.CharField(required=True, min_length=6, max_length=6)


class UserSessionSerializer(serializers.ModelSerializer):
    """Serializer for user sessions"""
    
    class Meta:
        model = UserSession
        fields = [
            'id', 'device_type', 'device_name', 'browser', 'os',
            'ip_address', 'country', 'city', 'is_active',
            'created_at', 'last_activity'
        ]
