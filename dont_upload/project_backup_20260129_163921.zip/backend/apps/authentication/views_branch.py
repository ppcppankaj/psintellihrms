"""
Branch Selector Views - Allow users to switch between branches
"""

from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django.core.cache import cache

from apps.authentication.models import Branch, BranchUser
from apps.core.middleware import set_current_branch


class BranchSelectorViewSet(viewsets.ViewSet):
    """
    ViewSet for branch selection and switching.
    
    Endpoints:
    - GET /api/v1/branches/my-branches/: List branches accessible to current user
    - POST /api/v1/branches/switch-branch/: Switch to a different branch
    - GET /api/v1/branches/current-branch/: Get current active branch
    """
    
    permission_classes = [IsAuthenticated]
    
    @action(detail=False, methods=['get'])
    def my_branches(self, request):
        """
        Get list of branches accessible to the current user.
        
        Returns:
            - branches: List of branches user can access
            - current_branch: Currently selected branch
            - is_multi_branch: Whether user has access to multiple branches
        """
        user = request.user
        
        # Get user's organization
        user_org = user.get_organization()
        if not user_org:
            # User has no organization - return empty branch list
            # This is normal for users on public schema or not yet assigned
            return Response({
                'branches': [],
                'current_branch': None,
                'is_multi_branch': False,
                'organization': None,
                'message': 'No organization assigned'
            })
        
        # Get accessible branches
        branches = self._get_user_branches(user)
        
        # Get current branch from session or default
        current_branch_id = request.session.get('current_branch_id')
        current_branch = None
        
        if current_branch_id:
            current_branch = Branch.objects.filter(
                id=current_branch_id,
                is_active=True
            ).first()
        
        # If no current branch or invalid, use first available
        if not current_branch and branches:
            current_branch = branches[0]
            request.session['current_branch_id'] = str(current_branch.id)
        
        return Response({
            'branches': [{
                'id': str(branch.id),
                'name': branch.name,
                'code': branch.code,
                'type': branch.branch_type,
                'location': branch.location.name if branch.location else None,
                'is_headquarters': branch.is_headquarters,
            } for branch in branches],
            'current_branch': {
                'id': str(current_branch.id),
                'name': current_branch.name,
                'code': current_branch.code,
            } if current_branch else None,
            'is_multi_branch': len(branches) > 1,
            'organization': {
                'id': str(user_org.id),
                'name': user_org.name,
            }
        })
    
    @action(detail=False, methods=['post'])
    def switch_branch(self, request):
        """
        Switch to a different branch.
        
        Body:
            - branch_id: ID of the branch to switch to
        
        Returns:
            - success: Whether switch was successful
            - branch: Details of the newly active branch
        """
        branch_id = request.data.get('branch_id')
        
        if not branch_id:
            return Response({
                'error': 'branch_id is required'
            }, status=status.HTTP_400_BAD_REQUEST)
        
        # Verify user has access to this branch
        user_branches = self._get_user_branches(request.user)
        branch_ids = [str(b.id) for b in user_branches]
        
        if branch_id not in branch_ids:
            return Response({
                'error': 'You do not have access to this branch'
            }, status=status.HTTP_403_FORBIDDEN)
        
        # Get the branch
        try:
            branch = Branch.objects.get(id=branch_id, is_active=True)
        except Branch.DoesNotExist:
            return Response({
                'error': 'Branch not found or inactive'
            }, status=status.HTTP_404_NOT_FOUND)
        
        # Store in session
        request.session['current_branch_id'] = str(branch.id)
        request.session.modified = True
        
        # Update thread-local context
        set_current_branch(branch)
        
        # Clear any branch-specific cache
        cache_key = f'user_branch_{request.user.id}'
        cache.delete(cache_key)
        
        return Response({
            'success': True,
            'message': f'Switched to branch: {branch.name}',
            'branch': {
                'id': str(branch.id),
                'name': branch.name,
                'code': branch.code,
                'type': branch.branch_type,
                'location': branch.location.name if branch.location else None,
            }
        })
    
    @action(detail=False, methods=['get'])
    def current_branch(self, request):
        """
        Get the currently active branch for the user.
        
        Returns:
            - branch: Current branch details
            - is_default: Whether this is the user's default branch
        """
        # Try to get from session
        current_branch_id = request.session.get('current_branch_id')
        current_branch = None
        
        if current_branch_id:
            current_branch = Branch.objects.filter(
                id=current_branch_id,
                is_active=True
            ).first()
        
        # Fallback to user's default branch
        if not current_branch:
            user_branches = self._get_user_branches(request.user)
            if user_branches:
                current_branch = user_branches[0]
                request.session['current_branch_id'] = str(current_branch.id)
        
        if not current_branch:
            return Response({
                'error': 'No branch assignment found'
            }, status=status.HTTP_404_NOT_FOUND)
        
        return Response({
            'branch': {
                'id': str(current_branch.id),
                'name': current_branch.name,
                'code': current_branch.code,
                'type': current_branch.branch_type,
                'location': current_branch.location.name if current_branch.location else None,
                'is_headquarters': current_branch.is_headquarters,
                'address': current_branch.address,
                'city': current_branch.city,
                'state': current_branch.state,
                'country': current_branch.country,
            },
            'is_default': current_branch_id is None,
        })
    
    def _get_user_branches(self, user):
        """
        Get all branches accessible to the user.
        
        Priority:
        1. Branches via BranchUser mapping (active memberships)
        2. Branch from Employee record (fallback)
        3. All branches in organization (if org admin)
        
        Returns:
            List of Branch objects
        """
        branches = []
        
        # Superusers and org admins see all branches in their org
        if user.is_superuser:
            return list(Branch.objects.filter(is_active=True))
        
        if user.is_org_admin or user.is_organization_admin():
            user_org = user.get_organization()
            if user_org:
                return list(Branch.objects.filter(
                    organization=user_org,
                    is_active=True
                ).order_by('is_headquarters', 'name'))
        
        # Try BranchUser mapping
        try:
            branch_memberships = BranchUser.objects.filter(
                user=user,
                is_active=True
            ).select_related('branch').order_by('branch__is_headquarters', 'branch__name')
            
            branches = [membership.branch for membership in branch_memberships if membership.branch.is_active]
        except:
            pass
        
        # Fallback to Employee branch
        if not branches:
            try:
                from apps.employees.models import Employee
                employee = Employee.objects.filter(
                    user=user,
                    is_active=True
                ).select_related('branch').first()
                
                if employee and employee.branch and employee.branch.is_active:
                    branches = [employee.branch]
            except:
                pass
        
        return branches
