"""
Custom JWT Authentication with Tenant Validation
SECURITY: Validates organization_id claim in JWT matches current request tenant
"""

import logging
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework_simplejwt.exceptions import InvalidToken, AuthenticationFailed
from django.utils.translation import gettext_lazy as _

logger = logging.getLogger(__name__)


class OrganizationAwareJWTAuthentication(JWTAuthentication):
    """
    JWT authentication with organization isolation enforcement.
    
    CRITICAL SECURITY: This validates that the organization_id claim in the JWT
    matches the organization resolved from the request.
    """
    
    def authenticate(self, request):
        """
        Authenticate the request and validate organization binding.
        """
        result = super().authenticate(request)
        
        if result is None:
            return None
        
        user, validated_token = result
        
        # CRITICAL: Validate organization binding
        self.validate_organization_binding(request, validated_token)
        
        return user, validated_token
    
    def validate_organization_binding(self, request, token):
        """
        SECURITY: Ensure JWT organization claim matches request organization.
        """
        # Skip validation for public paths
        public_paths = ['/api/v1/auth/', '/api/health/', '/api/docs/', '/api/redoc/']
        if any(request.path.startswith(p) for p in public_paths):
            return
        
        # Get organization from request (resolved by OrganizationMiddleware)
        request_org = getattr(request, 'organization', None)
        
        if not request_org:
            # If middleware hasn't run or failed, we can't validate
            if request.user.is_superuser:
                return
            logger.error("JWT validation: No organization on request.")
            raise AuthenticationFailed(_('Organization context missing'))
        
        # Get organization_id from JWT claim
        token_org_id = token.get('organization_id')
        
        if token_org_id is None:
            # Check if it's a legacy token or if organization is missing
            if not request.user.is_superuser:
                raise AuthenticationFailed(_('Organization binding missing in token'))
            return

        # Validate organization_id matches
        if str(request_org.id) != str(token_org_id):
            logger.error(
                f"SECURITY VIOLATION: Cross-organization token usage detected!\n"
                f"  Token org: {token_org_id}\n"
                f"  Request org: {request_org.id}\n"
                f"  User: {token.get('email')}"
            )
            raise AuthenticationFailed(
                _('Your credentials do not belong to this organization')
            )
        
        logger.debug(
            f"✓ JWT organization validation OK: {token.get('email')} @ {request_org.name}"
        )
