"""
Authentication Views
"""

import secrets
import pyotp
import qrcode
import io
import base64
from datetime import timedelta

from rest_framework import status, views, viewsets
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.decorators import api_view, permission_classes, action
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView
from rest_framework_simplejwt.tokens import RefreshToken
from django.utils import timezone
from django.conf import settings
from django.core.exceptions import PermissionDenied

from .models import User, UserSession, PasswordResetToken
from .serializers import (
    CustomTokenObtainPairSerializer, UserSerializer, UserCreateSerializer,
    UserOrgAdminCreateSerializer, UserSelfProfileSerializer, PasswordChangeSerializer, PasswordResetRequestSerializer,
    PasswordResetConfirmSerializer, TwoFactorEnableSerializer,
    TwoFactorVerifySerializer, UserSessionSerializer
)
from apps.core.org_permissions import IsOrgAdminOrSuperuser


class CustomTokenObtainPairView(TokenObtainPairView):
    """Enhanced login view with session tracking"""
    
    serializer_class = CustomTokenObtainPairSerializer
    
    def post(self, request, *args, **kwargs):
        response = super().post(request, *args, **kwargs)
        
        if response.status_code == 200:
            # Get user and record login
            email = request.data.get('email')
            try:
                user = User.objects.get(email=email)
                user.record_login_attempt(
                    success=True,
                    ip_address=self.get_client_ip(request),
                    device=request.META.get('HTTP_USER_AGENT', '')
                )
                
                # Create session record
                self.create_session(request, user, response.data.get('refresh'))
                
                # Update response data to match frontend expectation
                tokens = response.data
                response.data = {
                    'user': UserSerializer(user).data,
                    'tokens': tokens,
                    'requires_2fa': user.is_2fa_enabled and user.two_factor_secret != ''
                }
                
                # If 2FA is required, don't return tokens yet
                if response.data['requires_2fa']:
                    # Store session ID for 2FA verification
                    response.data['session_id'] = str(user.sessions.filter(is_active=True).first().id)
                    del response.data['tokens']
                    
            except User.DoesNotExist:
                pass
        
        return response
    
    def get_client_ip(self, request):
        x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
        if x_forwarded_for:
            return x_forwarded_for.split(',')[0].strip()
        return request.META.get('REMOTE_ADDR')
    
    def create_session(self, request, user, refresh_token):
        user_agent = request.META.get('HTTP_USER_AGENT', '')
        
        UserSession.objects.create(
            user=user,
            session_key=secrets.token_urlsafe(32),
            refresh_token=refresh_token,
            ip_address=self.get_client_ip(request),
            user_agent=user_agent,
            device_type=self.detect_device_type(user_agent),
            expires_at=timezone.now() + timedelta(days=7)
        )
    
    def detect_device_type(self, user_agent):
        ua_lower = user_agent.lower()
        if 'mobile' in ua_lower or 'android' in ua_lower or 'iphone' in ua_lower:
            return 'mobile'
        elif 'tablet' in ua_lower or 'ipad' in ua_lower:
            return 'tablet'
        return 'desktop'


class LogoutView(views.APIView):
    """Logout and invalidate tokens"""
    
    permission_classes = [IsAuthenticated]
    
    def post(self, request):
        try:
            refresh_token = request.data.get('refresh_token')
            if refresh_token:
                token = RefreshToken(refresh_token)
                token.blacklist()
            
            # Deactivate session
            UserSession.objects.filter(
                user=request.user,
                refresh_token=refresh_token
            ).update(is_active=False)
            
            return Response({'success': True, 'message': 'Logged out successfully'})
        except Exception as e:
            return Response({'success': False, 'message': str(e)}, status=status.HTTP_400_BAD_REQUEST)


class ProfileView(views.APIView):
    """
    🔒 SECURITY: User profile management
    - GET: View own profile (limited fields for org admins)
    - PATCH: Edit own profile (only allowed fields)
    """
    
    permission_classes = [IsAuthenticated]
    
    def get(self, request):
        """Get current user profile"""
        serializer = UserSelfProfileSerializer(request.user, context={'request': request})
        return Response({'success': True, 'data': serializer.data})
    
    def patch(self, request):
        """
        🔒 SECURITY: Edit own profile with restricted fields
        Org admins can only edit: first_name, last_name, email, phone, avatar, 
        date_of_birth, gender, timezone, language
        """
        serializer = UserSelfProfileSerializer(
            request.user,
            data=request.data,
            partial=True,
            context={'request': request}
        )
        if serializer.is_valid():
            serializer.save()
            return Response({
                'success': True,
                'message': 'Profile updated successfully',
                'data': serializer.data
            })
        return Response({
            'success': False,
            'errors': serializer.errors
        }, status=status.HTTP_400_BAD_REQUEST)


class PasswordChangeView(views.APIView):
    """Change password"""
    
    permission_classes = [IsAuthenticated]
    
    def post(self, request):
        serializer = PasswordChangeSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            request.user.set_password(serializer.validated_data['new_password'])
            request.user.password_changed_at = timezone.now()
            request.user.must_change_password = False
            request.user.save()
            
            return Response({'success': True, 'message': 'Password changed successfully'})
        return Response({'success': False, 'errors': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)


class PasswordResetRequestView(views.APIView):
    """Request password reset"""
    
    authentication_classes = []
    permission_classes = [AllowAny]
    
    def post(self, request):
        serializer = PasswordResetRequestSerializer(data=request.data)
        if serializer.is_valid():
            email = serializer.validated_data['email']
            
            try:
                user = User.objects.get(email=email, is_active=True)
                
                # Create reset token
                token = secrets.token_urlsafe(32)
                PasswordResetToken.objects.create(
                    user=user,
                    token=token,
                    expires_at=timezone.now() + timedelta(hours=1)
                )
                
                # TODO: Send email with reset link
                # send_password_reset_email(user, token)
                
            except User.DoesNotExist:
                pass  # Don't reveal if email exists
            
            return Response({
                'success': True,
                'message': 'If an account exists with this email, you will receive a password reset link.'
            })
        return Response({'success': False, 'errors': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)


class PasswordResetConfirmView(views.APIView):
    """Confirm password reset"""
    
    authentication_classes = []
    permission_classes = [AllowAny]
    
    def post(self, request):
        serializer = PasswordResetConfirmSerializer(data=request.data)
        if serializer.is_valid():
            token = serializer.validated_data['token']
            
            try:
                reset_token = PasswordResetToken.objects.get(token=token)
                
                if not reset_token.is_valid():
                    return Response({
                        'success': False,
                        'message': 'Invalid or expired token'
                    }, status=status.HTTP_400_BAD_REQUEST)
                
                user = reset_token.user
                user.set_password(serializer.validated_data['new_password'])
                user.password_changed_at = timezone.now()
                user.save()
                
                reset_token.is_used = True
                reset_token.save()
                
                return Response({'success': True, 'message': 'Password reset successfully'})
                
            except PasswordResetToken.DoesNotExist:
                return Response({
                    'success': False,
                    'message': 'Invalid token'
                }, status=status.HTTP_400_BAD_REQUEST)
        
        return Response({'success': False, 'errors': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)


class TwoFactorEnableView(views.APIView):
    """Enable 2FA"""
    
    permission_classes = [IsAuthenticated]
    
    def post(self, request):
        serializer = TwoFactorEnableSerializer(data=request.data)
        if serializer.is_valid():
            if not request.user.check_password(serializer.validated_data['password']):
                return Response({
                    'success': False,
                    'message': 'Invalid password'
                }, status=status.HTTP_400_BAD_REQUEST)
            
            # Generate secret
            secret = pyotp.random_base32()
            totp = pyotp.TOTP(secret)
            
            # Generate QR code
            provisioning_uri = totp.provisioning_uri(
                name=request.user.email,
                issuer_name='HRMS'
            )
            
            qr = qrcode.QRCode(version=1, box_size=10, border=5)
            qr.add_data(provisioning_uri)
            qr.make(fit=True)
            
            img = qr.make_image(fill_color="black", back_color="white")
            buffer = io.BytesIO()
            img.save(buffer, format='PNG')
            qr_code = base64.b64encode(buffer.getvalue()).decode()
            
            # Store secret temporarily (should be confirmed first)
            request.user.two_factor_secret = secret
            request.user.save()
            
            return Response({
                'success': True,
                'data': {
                    'secret': secret,
                    'qr_code': f'data:image/png;base64,{qr_code}'
                }
            })
        return Response({'success': False, 'errors': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)


class TwoFactorVerifyView(views.APIView):
    """Verify and activate 2FA"""
    
    permission_classes = [IsAuthenticated]
    
    def post(self, request):
        serializer = TwoFactorVerifySerializer(data=request.data)
        if serializer.is_valid():
            code = serializer.validated_data['code']
            
            if not request.user.two_factor_secret:
                return Response({
                    'success': False,
                    'message': '2FA not initialized. Please enable first.'
                }, status=status.HTTP_400_BAD_REQUEST)
            
            totp = pyotp.TOTP(request.user.two_factor_secret)
            
            if totp.verify(code):
                # Generate backup codes
                backup_codes = [secrets.token_hex(4).upper() for _ in range(10)]
                
                request.user.is_2fa_enabled = True
                request.user.backup_codes = backup_codes
                request.user.save()
                
                return Response({
                    'success': True,
                    'message': '2FA enabled successfully',
                    'backup_codes': backup_codes
                })
            
            return Response({
                'success': False,
                'message': 'Invalid verification code'
            }, status=status.HTTP_400_BAD_REQUEST)
        
        return Response({'success': False, 'errors': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)


class TwoFactorDisableView(views.APIView):
    """Disable 2FA"""
    
    permission_classes = [IsAuthenticated]
    
    def post(self, request):
        password = request.data.get('password')
        
        if not request.user.check_password(password):
            return Response({
                'success': False,
                'message': 'Invalid password'
            }, status=status.HTTP_400_BAD_REQUEST)
        
        request.user.is_2fa_enabled = False
        request.user.two_factor_secret = ''
        request.user.backup_codes = []
        request.user.save()
        
        return Response({'success': True, 'message': '2FA disabled successfully'})


class SessionListView(views.APIView):
    """List and manage user sessions"""
    
    permission_classes = [IsAuthenticated]
    
    def get(self, request):
        sessions = UserSession.objects.filter(
            user=request.user,
            is_active=True
        ).order_by('-last_activity')
        
        serializer = UserSessionSerializer(sessions, many=True)
        return Response({'success': True, 'data': serializer.data})
    
    def delete(self, request, session_id=None):
        """Logout from specific session"""
        try:
            session = UserSession.objects.get(
                id=session_id,
                user=request.user
            )
            session.is_active = False
            session.save()
            
            # Blacklist the refresh token
            if session.refresh_token:
                try:
                    token = RefreshToken(session.refresh_token)
                    token.blacklist()
                except:
                    pass
            
            return Response({'success': True, 'message': 'Session terminated'})
        except UserSession.DoesNotExist:
            return Response({
                'success': False,
                'message': 'Session not found'
            }, status=status.HTTP_404_NOT_FOUND)

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def user_profile(request):
    """Get current user profile with roles and permissions"""
    from django.db import connection
    
    user = request.user
    is_superuser = user.is_superuser
    
    # Get user roles and permissions (only in tenant schema)
    roles = []
    permissions = []
    
    if user.organization_id:
        try:
            from apps.abac.models import UserRole
            user_roles = UserRole.objects.filter(user=user, is_active=True)
            roles = [
                {
                    'id': str(ur.role.id),
                    'name': ur.role.name,
                    'code': ur.role.code,
                    'description': ur.role.description
                }
                for ur in user_roles
            ]
            
            # Get all permissions for this user
            permissions = user.get_all_permissions()
        except Exception:
            pass
    
    return Response({
        'success': True,
        'data': {
            'user': UserSerializer(user).data,
            'is_superuser': is_superuser,
            'is_organization_admin': user.is_superuser or user.is_org_admin,
            'roles': roles,
            'permissions': permissions,
            'current_organization': {
                'id': str(user.organization_id) if user.organization_id else None,
                'name': user.organization.name if user.organization else None
            }
        }
    })


class UserManagementViewSet(viewsets.ModelViewSet):
    """
    🔒 SECURITY: User management for org admins
    - Org admins can create, list, and update users in their organization
    - Org admins CANNOT modify their own account
    - Org admins CANNOT change organization or privilege fields
    - Superusers have full control
    """
    
    queryset = User.objects.all()
    permission_classes = [IsAuthenticated, IsOrgAdminOrSuperuser]
    serializer_class = UserSerializer
    
    def get_queryset(self):
        """
        🔒 SECURITY: Filter users by organization
        - Superusers see all users
        - Org admins see only their organization's users
        """
        user = self.request.user
        
        if user.is_superuser:
            return User.objects.all()
        
        if user.is_org_admin and user.organization:
            return User.objects.filter(organization=user.organization)
        
        return User.objects.none()
    
    def get_serializer_class(self):
        """Use secure serializer for creation"""
        if self.action == 'create':
            return UserOrgAdminCreateSerializer
        return UserSerializer
    
    def create(self, request, *args, **kwargs):
        """🔒 SECURITY: Create user with org admin validation"""
        if not request.user.is_org_admin and not request.user.is_superuser:
            raise PermissionDenied('Only org admins can create users')
        
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        
        headers = self.get_success_headers(serializer.data)
        return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)
    
    def update(self, request, *args, **kwargs):
        """
        🔒 SECURITY: Prevent org admin from modifying themselves or critical fields
        """
        user_id = kwargs.get('pk')
        target_user = self.get_object()
        
        # 🔒 CRITICAL: Org admin cannot modify their own account
        if str(target_user.pk) == str(request.user.pk) and request.user.is_org_admin:
            raise PermissionDenied('Organization admins cannot modify their own account')
        
        # 🔒 CRITICAL: Cannot change organization
        if 'organization' in request.data and not request.user.is_superuser:
            raise PermissionDenied('Only superusers can change organization')
        
        # 🔒 CRITICAL: Cannot escalate privileges
        if any(field in request.data for field in ['is_org_admin', 'is_staff', 'is_superuser']):
            if not request.user.is_superuser:
                raise PermissionDenied('Only superusers can modify privilege levels')
        
        return super().update(request, *args, **kwargs)
    
    def partial_update(self, request, *args, **kwargs):
        """
        🔒 SECURITY: Same restrictions as update()
        """
        # Apply same restrictions as update()
        return self.update(request, *args, **kwargs)
    
    @action(detail=False, methods=['get'], permission_classes=[IsAuthenticated])
    def my_users(self, request):
        """
        List all users in requesting user's organization
        (convenience endpoint for org admins)
        """
        if not request.user.is_org_admin:
            raise PermissionDenied('Only org admins can list organization users')
        
        users = self.get_queryset()
        serializer = self.get_serializer(users, many=True)
        return Response({
            'success': True,
            'organization': str(request.user.organization),
            'data': serializer.data
        })
