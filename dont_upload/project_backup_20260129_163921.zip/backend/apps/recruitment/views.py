"""
Recruitment ViewSets

Provides API endpoints for recruitment management including:
- Job Postings (branch-filtered)
- Candidates (organization-level, but linked to applications)
- Job Applications (branch-filtered via job posting)
- Interviews (branch-filtered)
- Offer Letters (branch-filtered via application/job)
"""

from rest_framework import viewsets, filters, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django_filters.rest_framework import DjangoFilterBackend

from apps.core.permissions_branch import BranchFilterBackend, BranchPermission

from .models import JobPosting, Candidate, JobApplication, Interview, OfferLetter
from .serializers import (
    JobPostingSerializer, CandidateSerializer, JobApplicationSerializer,
    InterviewSerializer, OfferLetterSerializer
)


class BranchFilterMixin:
    """Mixin providing branch filtering capabilities for recruitment ViewSets."""
    
    def get_branch_ids(self):
        """Get list of branch IDs the current user can access."""
        if self.request.user.is_superuser:
            return None  # Superuser can access all
        from apps.authentication.models_hierarchy import BranchUser
        return list(BranchUser.objects.filter(
            user=self.request.user,
            is_active=True
        ).values_list('branch_id', flat=True))


class JobPostingViewSet(BranchFilterMixin, viewsets.ModelViewSet):
    """
    ViewSet for job postings.
    Filtered by user's accessible branches.
    """
    queryset = JobPosting.objects.all()
    serializer_class = JobPostingSerializer
    permission_classes = [IsAuthenticated, BranchPermission]
    filter_backends = [BranchFilterBackend, DjangoFilterBackend, filters.SearchFilter]
    filterset_fields = ['status', 'department', 'location']
    search_fields = ['title', 'description']
    
    def get_queryset(self):
        queryset = super().get_queryset()
        branch_ids = self.get_branch_ids()
        if branch_ids is None:
            return queryset
        if not branch_ids:
            return queryset.none()
        # Filter by department's branch
        return queryset.filter(department__branch_id__in=branch_ids)


class CandidateViewSet(BranchFilterMixin, viewsets.ModelViewSet):
    """
    ViewSet for candidates.
    Candidates are filtered based on their applications to jobs in user's branches.
    """
    queryset = Candidate.objects.all()
    serializer_class = CandidateSerializer
    permission_classes = [IsAuthenticated, BranchPermission]
    filter_backends = [BranchFilterBackend, DjangoFilterBackend, filters.SearchFilter]
    search_fields = ['first_name', 'last_name', 'email']
    
    def get_queryset(self):
        queryset = super().get_queryset()
        branch_ids = self.get_branch_ids()
        if branch_ids is None:
            return queryset
        if not branch_ids:
            return queryset.none()
        # Filter candidates who have applied to jobs in user's branches
        return queryset.filter(
            applications__job__department__branch_id__in=branch_ids
        ).distinct()


class JobApplicationViewSet(BranchFilterMixin, viewsets.ModelViewSet):
    """
    ViewSet for job applications.
    Filtered by job posting's branch via department.
    """
    queryset = JobApplication.objects.all()
    serializer_class = JobApplicationSerializer
    permission_classes = [IsAuthenticated, BranchPermission]
    filter_backends = [BranchFilterBackend, DjangoFilterBackend]
    filterset_fields = ['stage', 'job']
    
    def get_queryset(self):
        queryset = super().get_queryset()
        branch_ids = self.get_branch_ids()
        if branch_ids is None:
            return queryset
        if not branch_ids:
            return queryset.none()
        # Filter by job's department's branch
        return queryset.filter(job__department__branch_id__in=branch_ids)

    @action(detail=True, methods=['post'])
    def change_stage(self, request, pk=None):
        """Move application to a new recruitment stage."""
        application = self.get_object()
        new_stage = request.data.get('stage')
        if new_stage:
            application.stage = new_stage
            application.save()
            return Response({'status': 'stage updated'})
        return Response({'error': 'stage not provided'}, status=status.HTTP_400_BAD_REQUEST)


class InterviewViewSet(BranchFilterMixin, viewsets.ModelViewSet):
    """
    ViewSet for interviews.
    Filtered by application's job's branch.
    """
    queryset = Interview.objects.all()
    serializer_class = InterviewSerializer
    permission_classes = [IsAuthenticated, BranchPermission]
    filter_backends = [BranchFilterBackend, DjangoFilterBackend]
    filterset_fields = ['status', 'round_type']
    
    def get_queryset(self):
        queryset = super().get_queryset()
        branch_ids = self.get_branch_ids()
        if branch_ids is None:
            return queryset
        if not branch_ids:
            return queryset.none()
        # Filter by application's job's department's branch
        return queryset.filter(application__job__department__branch_id__in=branch_ids)


class OfferLetterViewSet(BranchFilterMixin, viewsets.ModelViewSet):
    """
    ViewSet for offer letters.
    Contains sensitive compensation data - must be branch-filtered.
    """
    queryset = OfferLetter.objects.all()
    serializer_class = OfferLetterSerializer
    permission_classes = [IsAuthenticated, BranchPermission]
    filter_backends = [BranchFilterBackend, DjangoFilterBackend]
    filterset_fields = ['status']
    
    def get_queryset(self):
        queryset = super().get_queryset()
        branch_ids = self.get_branch_ids()
        if branch_ids is None:
            return queryset
        if not branch_ids:
            return queryset.none()
        # Filter by application's job's department's branch
        return queryset.filter(application__job__department__branch_id__in=branch_ids)
