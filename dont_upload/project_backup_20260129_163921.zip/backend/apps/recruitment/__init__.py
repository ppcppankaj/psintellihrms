"""Recruitment app - ATS"""
default_app_config = 'apps.recruitment.apps.RecruitmentConfig'
