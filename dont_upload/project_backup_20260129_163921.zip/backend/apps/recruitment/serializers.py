"""
Recruitment Serializers
"""

from rest_framework import serializers
from .models import JobPosting, Candidate, JobApplication, Interview, OfferLetter
from apps.employees.serializers import DepartmentSerializer, LocationSerializer, DesignationSerializer, EmployeeListSerializer

class JobPostingSerializer(serializers.ModelSerializer):
    department_details = DepartmentSerializer(source='department', read_only=True)
    location_details = LocationSerializer(source='location', read_only=True)
    designation_details = DesignationSerializer(source='designation', read_only=True)
    
    class Meta:
        model = JobPosting
        fields = '__all__'

class CandidateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Candidate
        fields = '__all__'

class JobApplicationSerializer(serializers.ModelSerializer):
    job_details = JobPostingSerializer(source='job', read_only=True)
    candidate_details = CandidateSerializer(source='candidate', read_only=True)
    
    class Meta:
        model = JobApplication
        fields = '__all__'

class InterviewSerializer(serializers.ModelSerializer):
    interviewers_details = EmployeeListSerializer(source='interviewers', many=True, read_only=True)
    
    class Meta:
        model = Interview
        fields = '__all__'

class OfferLetterSerializer(serializers.ModelSerializer):
    class Meta:
        model = OfferLetter
        fields = '__all__'
