"""
Notification Serializers
"""

from rest_framework import serializers
from .models import Notification, NotificationTemplate, NotificationPreference

class NotificationTemplateSerializer(serializers.ModelSerializer):
    class Meta:
        model = NotificationTemplate
        fields = '__all__'
        read_only_fields = ['organization', 'created_at', 'updated_at']

class NotificationSerializer(serializers.ModelSerializer):
    template_details = NotificationTemplateSerializer(source='template', read_only=True)
    
    class Meta:
        model = Notification
        fields = '__all__'
        read_only_fields = ['user', 'created_at', 'read_at', 'organization']


class NotificationPreferenceSerializer(serializers.ModelSerializer):
    """Serializer for user notification preferences"""
    class Meta:
        model = NotificationPreference
        fields = [
            'id',
            'email_enabled', 'push_enabled', 'sms_enabled',
            'leave_notifications', 'attendance_notifications',
            'payroll_notifications', 'task_notifications', 'announcement_notifications',
            'quiet_hours_enabled', 'quiet_hours_start', 'quiet_hours_end',
            'created_at', 'updated_at'
        ]
        read_only_fields = ['id', 'created_at', 'updated_at']
