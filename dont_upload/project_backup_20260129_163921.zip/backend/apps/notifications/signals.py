"""
Notification Signals
"""

from django.db.models.signals import post_save
from django.dispatch import receiver
from apps.workflows.models import WorkflowInstance, WorkflowAction
from .services import NotificationService

@receiver(post_save, sender=WorkflowInstance)
def notify_approver_on_workflow(sender, instance, created, **kwargs):
    """
    Notify the current approver when a workflow instance moves to a new step.
    """
    if instance.status == 'in_progress' and instance.current_approver:
        NotificationService.notify(
            user=instance.current_approver.user,
            title=f"New Approval Required: {instance.workflow.name}",
            message=f"A new {instance.entity_type} request requires your approval.",
            notification_type='action_required',
            entity_type='workflow_instance',
            entity_id=instance.id,
            priority='high'
        )

@receiver(post_save, sender=WorkflowAction)
def notify_initiator_on_action(sender, instance, created, **kwargs):
    """
    Notify the initiator when an action is taken on their workflow.
    """
    if created:
        # In a real app, you'd fetch the initiator from the instance entity
        # For now, we'll placeholder this or skip if too complex to resolve generically
        pass
        
