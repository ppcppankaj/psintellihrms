"""
Notification Services - In-app and Multi-channel notifications
"""

from django.utils import timezone
from .models import Notification

class NotificationService:
    """
    Service to handle creation and delivery of notifications.
    """

    @staticmethod
    def notify(user, title, message, notification_type='info', entity_type=None, entity_id=None, priority='medium'):
        """
        Create an in-app notification. 
        Email/SMS logic can be added here.
        """
        # Resolve User -> Employee
        # Handle case where user might be lazy object or user has no employee profile
        try:
            recipient = getattr(user, 'employee', None)
        except Exception:
            recipient = None
            
        if not recipient:
            # Cannot create notification for user without employee profile
            return None

        notification = Notification.objects.create(
            recipient=recipient,
            subject=title,
            body=message,
            channel='in_app',
            entity_type=entity_type or '',
            entity_id=entity_id,
        )
        
        # Email logic would be triggered here (e.g., via Celery)
        # cls._send_email(user.email, title, message)
        
        return notification

    @staticmethod
    def mark_all_as_read(user):
        """
        Mark all notifications for a user as read.
        """
        return Notification.objects.filter(recipient__user=user, is_read=False).update(
            status='read', 
            read_at=timezone.now()
        )

    @classmethod
    def send_template_notification(cls, user, template_code, context=None, entity_type=None, entity_id=None, priority='medium'):
        """
        Send a notification using a defined template.
        """
        from .models import NotificationTemplate
        context = context or {}
        
        try:
            # Fetch template - in real app, filter by tenant if needed
            template = NotificationTemplate.objects.get(code=template_code)
        except NotificationTemplate.DoesNotExist:
            print(f"Template {template_code} not found")
            return None
            
        # Basic jinja2-style variable replacement
        subject = template.subject
        body = template.body
        
        for key, value in context.items():
            placeholder = f"{{{{ {key} }}}}"
            subject = subject.replace(placeholder, str(value))
            body = body.replace(placeholder, str(value))
            
        return cls.notify(
            user=user, 
            title=subject, 
            message=body, 
            notification_type='info', 
            entity_type=entity_type, 
            entity_id=entity_id, 
            priority=priority,
            channel=template.channel
        )

    @staticmethod
    def notify(user, title, message, notification_type='info', entity_type=None, entity_id=None, priority='medium', channel='in_app'):
        """
        Create an in-app notification. 
        Email/SMS logic can be added here.
        """
        # Resolve User -> Employee
        # Handle case where user might be lazy object or user has no employee profile
        try:
            recipient = getattr(user, 'employee', None)
        except Exception:
            recipient = None
            
        if not recipient:
            # Cannot create notification for user without employee profile
            return None

        notification = Notification.objects.create(
            recipient=recipient,
            subject=title,
            body=message,
            channel=channel,
            entity_type=entity_type or '',
            entity_id=entity_id,
        )
        
        # Email logic would be triggered here (e.g., via Celery)
        # cls._send_email(user.email, title, message)
        
        return notification
