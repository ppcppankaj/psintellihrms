"""Leave app initialization"""
default_app_config = 'apps.leave.apps.LeaveConfig'
