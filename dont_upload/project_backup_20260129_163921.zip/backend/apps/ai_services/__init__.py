"""AI Services app"""
default_app_config = 'apps.ai_services.apps.AIServicesConfig'
