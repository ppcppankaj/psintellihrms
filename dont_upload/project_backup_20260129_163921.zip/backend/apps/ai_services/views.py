"""AI ViewSets

SECURITY:
- AIModelVersionViewSet: Superuser only (manages ML models)
- AIPredictionViewSet: Authenticated users (read), Superuser (write)
"""
from rest_framework import viewsets, filters, permissions
from .models import AIModelVersion, AIPrediction
from .serializers import AIModelVersionSerializer, AIPredictionSerializer


class IsSuperuserOnly(permissions.BasePermission):
    """Only allow superusers to access these endpoints."""
    def has_permission(self, request, view):
        return request.user and request.user.is_authenticated and request.user.is_superuser


class IsSuperuserOrReadOnly(permissions.BasePermission):
    """Allow read for authenticated users, write only for superusers."""
    def has_permission(self, request, view):
        if not request.user or not request.user.is_authenticated:
            return False
        if request.method in permissions.SAFE_METHODS:
            return True
        return request.user.is_superuser


class AIModelVersionViewSet(viewsets.ModelViewSet):
    """AI Model Version management - Superuser only"""
    queryset = AIModelVersion.objects.all()
    serializer_class = AIModelVersionSerializer
    permission_classes = [IsSuperuserOnly]
    filterset_fields = ['model_type', 'is_active']


class AIPredictionViewSet(viewsets.ModelViewSet):
    """AI Predictions - Read for authenticated, Write for superuser"""
    queryset = AIPrediction.objects.all()
    serializer_class = AIPredictionSerializer
    permission_classes = [IsSuperuserOrReadOnly]
    filterset_fields = ['entity_type', 'human_reviewed']
