# Chat app package
default_app_config = 'apps.chat.apps.ChatConfig'
