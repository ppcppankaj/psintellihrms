"""Onboarding Module - Employee Onboarding with Checklist Workflows"""
default_app_config = 'apps.onboarding.apps.OnboardingConfig'
