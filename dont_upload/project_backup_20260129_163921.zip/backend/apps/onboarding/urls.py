"""Onboarding URL Configuration"""

from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import (
    OnboardingTemplateViewSet, OnboardingTaskTemplateViewSet,
    EmployeeOnboardingViewSet, OnboardingTaskProgressViewSet,
    OnboardingDocumentViewSet
)

router = DefaultRouter()
router.register(r'templates', OnboardingTemplateViewSet, basename='onboarding-template')
router.register(r'task-templates', OnboardingTaskTemplateViewSet, basename='onboarding-task-template')
router.register(r'onboardings', EmployeeOnboardingViewSet, basename='employee-onboarding')
router.register(r'tasks', OnboardingTaskProgressViewSet, basename='onboarding-task')
router.register(r'documents', OnboardingDocumentViewSet, basename='onboarding-document')

urlpatterns = [
    path('', include(router.urls)),
]
