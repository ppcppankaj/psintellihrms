"""Onboarding Signals"""

from django.db.models.signals import post_save
from django.dispatch import receiver
from apps.employees.models import Employee
from .services import OnboardingService


@receiver(post_save, sender=Employee)
def auto_initiate_onboarding(sender, instance, created, **kwargs):
    """
    Optionally auto-initiate onboarding when a new employee is created.
    This is disabled by default - onboarding should be explicitly initiated.
    """
    # Uncomment below to enable auto-onboarding
    # if created and instance.date_of_joining:
    #     try:
    #         OnboardingService.initiate_onboarding(instance)
    #     except ValueError:
    #         pass  # No template found, skip
    pass
