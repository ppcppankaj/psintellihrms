"""Billing ViewSets"""
from rest_framework import viewsets, filters, permissions
from rest_framework.decorators import action
from rest_framework.response import Response
from .models import Plan, Subscription, Invoice, Payment, BankDetails
from .serializers import (
    PlanSerializer, SubscriptionSerializer, InvoiceSerializer, 
    PaymentSerializer, BankDetailsSerializer
)
from apps.core.permissions import IsSuperAdmin

class PlanViewSet(viewsets.ModelViewSet):
    """
    Plans:
    - Super Admin: CRUD
    - Tenants: Read Only
    """
    queryset = Plan.objects.all()
    serializer_class = PlanSerializer
    
    def get_permissions(self):
        if self.action in ['create', 'update', 'partial_update', 'destroy']:
            return [IsSuperAdmin()] # Or IsAuthenticated & IsSuperUser
        return [permissions.IsAuthenticated()]

class SubscriptionViewSet(viewsets.ModelViewSet):
    """
    Subscriptions:
    - Managed via Admin usually, or auto-created.
    - Tenants should see their own.
    """
    queryset = Subscription.objects.all()
    serializer_class = SubscriptionSerializer
    filterset_fields = ['status', 'tenant']
    
    def get_queryset(self):
        user = self.request.user
        if hasattr(user, 'is_superuser') and user.is_superuser:
            return Subscription.objects.all()
        # For tenants, show only their subscription
        if hasattr(user, 'tenant'):
            return Subscription.objects.filter(organization=user.organization)
        return Subscription.objects.none()

    def get_permissions(self):
        if self.action in ['create', 'update', 'partial_update', 'destroy']:
            return [IsSuperAdmin()]
        return [permissions.IsAuthenticated()]

class InvoiceViewSet(viewsets.ModelViewSet):
    """
    Invoices:
    - Super Admin: CRUD (Create manually)
    - Tenants: Read List/Retrieve own
    """
    queryset = Invoice.objects.all()
    serializer_class = InvoiceSerializer
    filterset_fields = ['status', 'subscription']
    
    def get_queryset(self):
        user = self.request.user
        if hasattr(user, 'is_superuser') and user.is_superuser:
            return Invoice.objects.all()
        
        # Tenants view their own invoices
        if hasattr(user, 'tenant'):
            # Find subscription for this tenant
            return Invoice.objects.filter(subscription__organization=user.organization)
        return Invoice.objects.none()
        
    def get_permissions(self):
        if self.action in ['create', 'update', 'partial_update', 'destroy']:
            return [IsSuperAdmin()]
        return [permissions.IsAuthenticated()]

class PaymentViewSet(viewsets.ModelViewSet):
    queryset = Payment.objects.all()
    serializer_class = PaymentSerializer
    filterset_fields = ['status', 'invoice']

    def get_queryset(self):
        user = self.request.user
        if getattr(user, 'is_superuser', False):
            return Payment.objects.all()
        if hasattr(user, 'tenant'):
            return Payment.objects.filter(invoice__subscription__organization=user.organization)
        return Payment.objects.none()

    def get_permissions(self):
        if self.action in ['create', 'update', 'partial_update', 'destroy']:
            return [IsSuperAdmin()]
        return [permissions.IsAuthenticated()]

class BankDetailsViewSet(viewsets.ModelViewSet):
    """
    Bank Details:
    - Super Admin: CRUD
    - Tenants: Read Only
    """
    queryset = BankDetails.objects.none() # Required for router basename, overridden by get_queryset
    serializer_class = BankDetailsSerializer
    
    def get_queryset(self):
        # Always fetch bank details (Provider's bank details)
        return BankDetails.objects.filter(is_active=True)

    def get_permissions(self):
        if self.action in ['create', 'update', 'partial_update', 'destroy']:
            return [IsSuperAdmin()]
        return [permissions.IsAuthenticated()]
