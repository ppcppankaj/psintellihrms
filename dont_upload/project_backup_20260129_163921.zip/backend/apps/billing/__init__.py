"""Billing app"""
default_app_config = 'apps.billing.apps.BillingConfig'
