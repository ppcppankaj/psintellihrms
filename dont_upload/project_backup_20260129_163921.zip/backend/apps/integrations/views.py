"""Integration ViewSets

SECURITY: All integration management endpoints require superuser access.
These endpoints expose sensitive system configuration (API keys, webhooks).
"""
from rest_framework import viewsets, filters, permissions
from rest_framework.exceptions import PermissionDenied
from .models import Integration, Webhook, APIKey
from .serializers import IntegrationSerializer, WebhookSerializer, APIKeySerializer


class IsSuperuserOnly(permissions.BasePermission):
    """Only allow superusers to access these endpoints."""
    def has_permission(self, request, view):
        return request.user and request.user.is_authenticated and request.user.is_superuser


class IntegrationViewSet(viewsets.ModelViewSet):
    """Integration management - Superuser only"""
    queryset = Integration.objects.all()
    serializer_class = IntegrationSerializer
    permission_classes = [IsSuperuserOnly]
    filterset_fields = ['provider', 'is_connected']


class WebhookViewSet(viewsets.ModelViewSet):
    """Webhook management - Superuser only"""
    queryset = Webhook.objects.all()
    serializer_class = WebhookSerializer
    permission_classes = [IsSuperuserOnly]
    filterset_fields = ['is_active']


class APIKeyViewSet(viewsets.ModelViewSet):
    """API Key management - Superuser only"""
    queryset = APIKey.objects.all()
    serializer_class = APIKeySerializer
    permission_classes = [IsSuperuserOnly]
