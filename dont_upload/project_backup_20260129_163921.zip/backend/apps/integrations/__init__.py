"""Integrations app"""
default_app_config = 'apps.integrations.apps.IntegrationsConfig'
