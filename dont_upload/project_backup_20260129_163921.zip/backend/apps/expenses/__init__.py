"""Expenses Module - Expense Claims & Employee Advances"""
default_app_config = 'apps.expenses.apps.ExpensesConfig'
