"""
Asset Management Views
"""

from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.filters import SearchFilter, OrderingFilter

from apps.core.tenant_guards import OrganizationViewSetMixin
from apps.core.mixins import BulkImportExportMixin
from apps.core.permissions_branch import BranchFilterBackend, BranchPermission
from apps.abac.permissions import ABACPermission

from .models import AssetCategory, Asset, AssetAssignment
from .serializers import (
    AssetCategorySerializer,
    AssetSerializer,
    AssetListSerializer,
    AssetDetailSerializer,
    AssetAssignmentSerializer,
    AssignAssetSerializer,
    UnassignAssetSerializer,
    AssetBulkImportSerializer,
)


class AssetCategoryViewSet(BulkImportExportMixin, OrganizationViewSetMixin, viewsets.ModelViewSet):
    """ViewSet for asset categories"""
    
    queryset = AssetCategory.objects.filter(is_deleted=False)
    serializer_class = AssetCategorySerializer
    permission_classes = [IsAuthenticated]
    filter_backends = [SearchFilter, OrderingFilter]
    search_fields = ['name', 'code']
    ordering_fields = ['name', 'created_at']


class AssetViewSet(BulkImportExportMixin, OrganizationViewSetMixin, viewsets.ModelViewSet):
    """ViewSet for managing assets"""
    
    queryset = Asset.objects.filter(is_deleted=False).select_related('category', 'current_assignee')
    permission_classes = [IsAuthenticated, BranchPermission]
    filter_backends = [BranchFilterBackend, DjangoFilterBackend, SearchFilter, OrderingFilter]
    filterset_fields = ['category', 'status', 'current_assignee']
    search_fields = ['name', 'asset_tag', 'serial_number']
    ordering_fields = ['name', 'asset_tag', 'purchase_date', 'created_at']
    
    def get_import_serializer_class(self):
        return AssetBulkImportSerializer

    def get_serializer_class(self):
        if self.action == 'list':
            return AssetListSerializer
        elif self.action == 'retrieve':
            return AssetDetailSerializer
        return AssetSerializer
    
    @action(detail=True, methods=['post'])
    def assign(self, request, pk=None):
        """Assign asset to an employee"""
        asset = self.get_object()
        
        if asset.status == Asset.ASSIGNED:
            return Response(
                {'success': False, 'message': 'Asset is already assigned'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        serializer = AssignAssetSerializer(data=request.data)
        if serializer.is_valid():
            from apps.employees.models import Employee
            try:
                employee = Employee.objects.get(id=serializer.validated_data['employee_id'])
            except Employee.DoesNotExist:
                return Response(
                    {'success': False, 'message': 'Employee not found'},
                    status=status.HTTP_404_NOT_FOUND
                )
            
            assignment = asset.assign_to(
                employee=employee,
                assigned_by=request.user,
                notes=serializer.validated_data.get('notes', '')
            )
            
            return Response({
                'success': True,
                'message': f'Asset assigned to {employee.full_name}',
                'data': AssetAssignmentSerializer(assignment).data
            })
        
        return Response({'success': False, 'errors': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)
    
    @action(detail=True, methods=['post'])
    def unassign(self, request, pk=None):
        """Return asset from current assignee"""
        asset = self.get_object()
        
        if not asset.current_assignee:
            return Response(
                {'success': False, 'message': 'Asset is not currently assigned'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        serializer = UnassignAssetSerializer(data=request.data)
        if serializer.is_valid():
            assignee_name = asset.current_assignee.full_name
            asset.unassign(
                returned_by=request.user,
                notes=serializer.validated_data.get('notes', '')
            )
            
            return Response({
                'success': True,
                'message': f'Asset returned from {assignee_name}'
            })
        
        return Response({'success': False, 'errors': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)
    
    @action(detail=False, methods=['get'])
    def stats(self, request):
        """Get asset statistics"""
        queryset = self.get_queryset()
        
        stats = {
            'total': queryset.count(),
            'available': queryset.filter(status=Asset.AVAILABLE).count(),
            'assigned': queryset.filter(status=Asset.ASSIGNED).count(),
            'maintenance': queryset.filter(status=Asset.MAINTENANCE).count(),
            'retired': queryset.filter(status=Asset.RETIRED).count(),
        }
        
        # By category
        from django.db.models import Count
        by_category = queryset.values('category__name').annotate(count=Count('id'))
        stats['by_category'] = list(by_category)
        
        return Response({'success': True, 'data': stats})


class AssetAssignmentViewSet(OrganizationViewSetMixin, viewsets.ModelViewSet):
    """ViewSet for asset assignments (history)"""
    
    queryset = AssetAssignment.objects.select_related('asset', 'employee', 'assigned_by')
    serializer_class = AssetAssignmentSerializer
    permission_classes = [IsAuthenticated]
    filter_backends = [DjangoFilterBackend, OrderingFilter]
    filterset_fields = ['asset', 'employee', 'returned_date']
    ordering_fields = ['assigned_date', 'returned_date']
