"""
Asset Management URLs
"""

from django.urls import path, include
from rest_framework.routers import DefaultRouter

from .views import AssetCategoryViewSet, AssetViewSet, AssetAssignmentViewSet

router = DefaultRouter()
router.register(r'categories', AssetCategoryViewSet, basename='asset-categories')
router.register(r'assets', AssetViewSet, basename='assets')
router.register(r'assignments', AssetAssignmentViewSet, basename='asset-assignments')

urlpatterns = [
    path('', include(router.urls)),
]
