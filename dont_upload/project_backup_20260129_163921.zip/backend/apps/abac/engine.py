"""
ABAC Policy Engine - Evaluates attribute-based access control policies
"""

from typing import Dict, Any, Optional, List
from django.conf import settings
from django.utils import timezone
from .models import Policy, PolicyLog, UserPolicy, GroupPolicy


class PolicyEngine:
    """
    Main engine for evaluating ABAC policies.
    Determines if a user has access to perform an action on a resource.
    """
    
    def __init__(self, user, log_decisions=True):
        self.user = user
        self.log_decisions = log_decisions
    
    def check_access(self, resource_type: str, action: str, 
                    resource_attrs: Dict[str, Any] = None,
                    resource_id: str = None) -> bool:
        """
        Main entry point for access control checks.
        
        Args:
            resource_type: Type of resource (e.g., 'employee', 'payroll')
            action: Action being performed (e.g., 'view', 'create', 'update', 'delete')
            resource_attrs: Attributes of the resource being accessed
            resource_id: Optional ID of specific resource
        
        Returns:
            bool: True if access is granted, False otherwise
        """
        # Superusers always have access
        if self.user.is_superuser:
            return True
        
        # Prepare attribute dictionaries
        subject_attrs = self._get_subject_attributes()
        resource_attrs = resource_attrs or {}
        environment_attrs = self._get_environment_attributes()
        
        # Get applicable policies
        policies = self._get_applicable_policies(resource_type, action, resource_id)
        
        # Evaluate policies
        decision, reason, evaluated_policies = self._evaluate_policies(
            policies, subject_attrs, resource_attrs, action, environment_attrs
        )
        
        # Log decision if enabled
        if self.log_decisions:
            self._log_decision(
                resource_type, resource_id or '', action, decision, 
                subject_attrs, resource_attrs, environment_attrs,
                evaluated_policies, reason
            )
        
        return decision
    
    def _get_subject_attributes(self) -> Dict[str, Any]:
        """Extract attributes from the user (subject)"""
        attrs = {
            'user_id': str(self.user.id),
            'email': self.user.email,
            'is_superuser': self.user.is_superuser,
            'is_verified': self.user.is_verified,
        }
        
        # Add employee attributes if available
        if hasattr(self.user, 'employee') and self.user.employee:
            emp = self.user.employee
            attrs.update({
                'employee_id': emp.employee_id,
                'department': emp.department.name if emp.department else None,
                'department_id': str(emp.department.id) if emp.department else None,
                'designation': emp.designation.name if emp.designation else None,
                'job_level': getattr(emp.designation, 'level', None) if emp.designation else None,
                'location': emp.location.name if emp.location else None,
                'location_id': str(emp.location.id) if emp.location else None,
                'employment_status': emp.employment_status,
                'employment_type': emp.employment_type,
                'date_of_joining': emp.date_of_joining,
                'is_manager': emp.is_manager if hasattr(emp, 'is_manager') else False,
                'manager_id': str(emp.manager.id) if emp.manager else None,
            })
        
        return attrs
    
    def _get_environment_attributes(self) -> Dict[str, Any]:
        """Extract environmental/contextual attributes"""
        now = timezone.now()
        
        return {
            'current_time': now.time().isoformat(),
            'current_date': now.date().isoformat(),
            'current_datetime': now.isoformat(),
            'day_of_week': now.strftime('%A'),
            'is_weekend': now.weekday() >= 5,
            'hour': now.hour,
            # Add request context if available
            # 'ip_address': ...,
            # 'user_agent': ...,
        }
    
    def _get_applicable_policies(self, resource_type: str, action: str, 
                                resource_id: Optional[str] = None) -> List[Policy]:
        """
        Get all policies that might apply to this access request.
        Ordered by priority (highest first).
        """
        # Get user-specific policies
        user_policies = UserPolicy.objects.filter(
            user=self.user,
            is_active=True
        ).select_related('policy')
        
        active_user_policies = [
            up.policy for up in user_policies 
            if up.is_valid_now() and up.policy.is_active and up.policy.is_valid_now()
        ]
        
        # Get group-based policies (based on user attributes)
        subject_attrs = self._get_subject_attributes()
        group_policies = self._get_group_policies(subject_attrs)
        
        # Combine and deduplicate
        all_policies = list(set(active_user_policies + group_policies))
        
        # Filter by resource type and action
        applicable = []
        for policy in all_policies:
            # Check if policy applies to this resource type
            if policy.resource_type and policy.resource_type != resource_type:
                continue
            
            # Check if policy applies to this action
            if policy.actions and action not in policy.actions:
                continue
            
            # Check if policy applies to specific resource
            if policy.resource_id and resource_id and policy.resource_id != resource_id:
                continue
            
            applicable.append(policy)
        
        # Sort by priority (highest first)
        applicable.sort(key=lambda p: p.priority, reverse=True)
        
        return applicable
    
    def _get_group_policies(self, subject_attrs: Dict[str, Any]) -> List[Policy]:
        """Get policies assigned to groups that the user belongs to"""
        group_policies = []
        
        # Get group policy assignments
        active_groups = GroupPolicy.objects.filter(is_active=True).prefetch_related('policies')
        
        for group in active_groups:
            # Check if user belongs to this group
            if group.group_type == 'department':
                if subject_attrs.get('department') == group.group_value:
                    group_policies.extend(list(group.policies.filter(is_active=True)))
            elif group.group_type == 'location':
                if subject_attrs.get('location') == group.group_value:
                    group_policies.extend(list(group.policies.filter(is_active=True)))
            elif group.group_type == 'job_level':
                if subject_attrs.get('job_level') == group.group_value:
                    group_policies.extend(list(group.policies.filter(is_active=True)))
            elif group.group_type == 'employment_type':
                if subject_attrs.get('employment_type') == group.group_value:
                    group_policies.extend(list(group.policies.filter(is_active=True)))
        
        return group_policies
    
    def _evaluate_policies(self, policies: List[Policy], subject_attrs: Dict,
                          resource_attrs: Dict, action: str, 
                          environment_attrs: Dict) -> tuple:
        """
        Evaluate all applicable policies and return decision.
        
        Returns:
            (decision: bool, reason: str, evaluated_policy_ids: list)
        """
        if not policies:
            # No applicable policies - default deny
            return False, "No applicable policies found", []
        
        deny_policies = []
        allow_policies = []
        evaluated_ids = []
        
        for policy in policies:
            evaluated_ids.append(str(policy.id))
            
            # Evaluate policy
            matches = policy.evaluate(subject_attrs, resource_attrs, action, environment_attrs)
            
            if matches:
                if policy.effect == Policy.DENY:
                    deny_policies.append(policy)
                else:  # ALLOW
                    allow_policies.append(policy)
        
        # DENY takes precedence over ALLOW
        if deny_policies:
            policy_names = ', '.join([p.name for p in deny_policies])
            return False, f"Denied by policy: {policy_names}", evaluated_ids
        
        if allow_policies:
            policy_names = ', '.join([p.name for p in allow_policies])
            return True, f"Allowed by policy: {policy_names}", evaluated_ids
        
        # No matching policies - default deny
        return False, "No matching policy rules", evaluated_ids
    
    def _log_decision(self, resource_type: str, resource_id: str, action: str,
                     result: bool, subject_attrs: Dict, resource_attrs: Dict,
                     environment_attrs: Dict, evaluated_policies: List,
                     reason: str):
        """Log the access decision for audit purposes"""
        try:
            PolicyLog.objects.create(
                user=self.user,
                resource_type=resource_type,
                resource_id=resource_id,
                action=action,
                result=result,
                subject_attributes=subject_attrs,
                resource_attributes=resource_attrs,
                environment_attributes=environment_attrs,
                policies_evaluated=evaluated_policies,
                decision_reason=reason,
                organization=self.user.organization if hasattr(self.user, 'tenant') else None,
            )
        except Exception as e:
            # Don't fail access check if logging fails
            import logging
            logger = logging.getLogger(__name__)
            logger.error(f"Failed to log policy decision: {e}")


class PolicyHelper:
    """
    Helper methods for common policy operations.
    """
    
    @staticmethod
    def create_department_access_policy(department_name: str, actions: List[str],
                                       resource_type: str = None) -> Policy:
        """
        Create a policy that grants access to users in a specific department.
        """
        from .models import AttributeType, PolicyRule
        
        policy = Policy.objects.create(
            name=f"Department {department_name} - {resource_type or 'All'} Access",
            code=f"dept_{department_name.lower().replace(' ', '_')}_{resource_type or 'all'}",
            description=f"Allows {', '.join(actions)} actions for {department_name} department",
            policy_type=Policy.MODULE if resource_type else Policy.GENERAL,
            effect=Policy.ALLOW,
            resource_type=resource_type or '',
            actions=actions,
            priority=10,
        )
        
        # Create rule: user.department == department_name
        dept_attr, _ = AttributeType.objects.get_or_create(
            code='user_department',
            defaults={
                'name': 'User Department',
                'category': AttributeType.SUBJECT,
                'data_type': AttributeType.STRING,
            }
        )
        
        PolicyRule.objects.create(
            policy=policy,
            attribute_type=dept_attr,
            attribute_path='department',
            operator=PolicyRule.EQUALS,
            value=department_name,
        )
        
        return policy
    
    @staticmethod
    def create_manager_access_policy(actions: List[str], resource_type: str = None) -> Policy:
        """
        Create a policy that grants access to managers.
        """
        from .models import AttributeType, PolicyRule
        
        policy = Policy.objects.create(
            name=f"Manager - {resource_type or 'All'} Access",
            code=f"manager_{resource_type or 'all'}",
            description=f"Allows {', '.join(actions)} actions for managers",
            policy_type=Policy.MODULE if resource_type else Policy.GENERAL,
            effect=Policy.ALLOW,
            resource_type=resource_type or '',
            actions=actions,
            priority=15,
        )
        
        # Create rule: user.is_manager == True
        manager_attr, _ = AttributeType.objects.get_or_create(
            code='is_manager',
            defaults={
                'name': 'Is Manager',
                'category': AttributeType.SUBJECT,
                'data_type': AttributeType.BOOLEAN,
            }
        )
        
        PolicyRule.objects.create(
            policy=policy,
            attribute_type=manager_attr,
            attribute_path='is_manager',
            operator=PolicyRule.EQUALS,
            value=True,
        )
        
        return policy
    
    @staticmethod
    def create_time_restricted_policy(start_hour: int, end_hour: int, 
                                     actions: List[str], resource_type: str = None) -> Policy:
        """
        Create a policy that only grants access during specific hours.
        """
        from .models import AttributeType, PolicyRule
        
        policy = Policy.objects.create(
            name=f"Time-Restricted {resource_type or 'All'} Access ({start_hour}:00-{end_hour}:00)",
            code=f"time_restricted_{resource_type or 'all'}_{start_hour}_{end_hour}",
            description=f"Allows {', '.join(actions)} only between {start_hour}:00 and {end_hour}:00",
            policy_type=Policy.GENERAL,
            effect=Policy.ALLOW,
            resource_type=resource_type or '',
            actions=actions,
            combine_logic=Policy.COMBINE_AND,
            priority=5,
        )
        
        # Create time attribute
        hour_attr, _ = AttributeType.objects.get_or_create(
            code='current_hour',
            defaults={
                'name': 'Current Hour',
                'category': AttributeType.ENVIRONMENT,
                'data_type': AttributeType.NUMBER,
            }
        )
        
        # Rule 1: hour >= start_hour
        PolicyRule.objects.create(
            policy=policy,
            attribute_type=hour_attr,
            attribute_path='hour',
            operator=PolicyRule.GREATER_THAN_EQUAL,
            value=start_hour,
        )
        
        # Rule 2: hour < end_hour
        PolicyRule.objects.create(
            policy=policy,
            attribute_type=hour_attr,
            attribute_path='hour',
            operator=PolicyRule.LESS_THAN,
            value=end_hour,
        )
        
        return policy
