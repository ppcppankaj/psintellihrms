"""
ABAC Permissions - Custom DRF permissions using Attribute-Based Access Control
"""

from rest_framework.permissions import BasePermission
from django.utils import timezone
from .engine import PolicyEngine


class HasABACPermission(BasePermission):
    """
    Base ABAC permission class.
    Checks access based on policies using the PolicyEngine.
    """
    
    def __init__(self, resource_type=None, action_map=None):
        """
        Args:
            resource_type: Type of resource (e.g., 'employee', 'payroll')
            action_map: Mapping of HTTP methods to ABAC actions
                       Default: {'GET': 'view', 'POST': 'create', 'PUT': 'update', 'PATCH': 'update', 'DELETE': 'delete'}
        """
        self.resource_type = resource_type
        self.action_map = action_map or {
            'GET': 'view',
            'POST': 'create',
            'PUT': 'update',
            'PATCH': 'update',
            'DELETE': 'delete',
        }
    
    def has_permission(self, request, view):
        if not request.user.is_authenticated:
            return False
        
        # Superusers always have access
        if request.user.is_superuser:
            return True
        
        # Determine resource type
        resource_type = self.resource_type or getattr(view, 'abac_resource_type', None)
        if not resource_type:
            # Try to infer from view
            resource_type = self._infer_resource_type(view)
        
        # Determine action
        action = self.action_map.get(request.method, 'view')
        if hasattr(view, 'action'):
            # Handle custom actions (e.g., @action decorators)
            action = getattr(view, 'abac_action', view.action)
        
        # Create policy engine and check access
        engine = PolicyEngine(request.user)
        return engine.check_access(resource_type, action)
    
    def has_object_permission(self, request, view, obj):
        """Check object-level permissions"""
        if not request.user.is_authenticated:
            return False
        
        if request.user.is_superuser:
            return True
        
        # Determine resource type and action
        resource_type = self.resource_type or getattr(view, 'abac_resource_type', None)
        if not resource_type:
            resource_type = self._infer_resource_type(view)
        
        action = self.action_map.get(request.method, 'view')
        if hasattr(view, 'action'):
            action = getattr(view, 'abac_action', view.action)
        
        # Extract resource attributes from object
        resource_attrs = self._extract_resource_attributes(obj)
        resource_id = str(obj.id) if hasattr(obj, 'id') else None
        
        # Check access with resource context
        engine = PolicyEngine(request.user)
        return engine.check_access(resource_type, action, resource_attrs, resource_id)
    
    def _infer_resource_type(self, view):
        """Infer resource type from view class name"""
        view_name = view.__class__.__name__
        # Remove 'ViewSet' or 'View' suffix and convert to lowercase
        resource_type = view_name.replace('ViewSet', '').replace('View', '').lower()
        return resource_type
    
    def _extract_resource_attributes(self, obj):
        """Extract attributes from resource object for policy evaluation"""
        attrs = {'id': str(obj.id) if hasattr(obj, 'id') else None}
        
        # Common attributes
        if hasattr(obj, 'department'):
            attrs['department'] = obj.department.name if obj.department else None
            attrs['department_id'] = str(obj.department.id) if obj.department else None
        
        if hasattr(obj, 'location'):
            attrs['location'] = obj.location.name if obj.location else None
            attrs['location_id'] = str(obj.location.id) if obj.location else None
        
        if hasattr(obj, 'owner') or hasattr(obj, 'user'):
            owner = getattr(obj, 'owner', None) or getattr(obj, 'user', None)
            attrs['owner_id'] = str(owner.id) if owner else None
        
        if hasattr(obj, 'confidential'):
            attrs['confidential'] = obj.confidential
        
        if hasattr(obj, 'status'):
            attrs['status'] = obj.status
        
        return attrs


class ABACPermission(HasABACPermission):
    """
    Simple ABAC permission class that can be used directly in views.
    Usage: permission_classes = [ABACPermission]
    
    Set abac_resource_type on the view to specify resource type,
    otherwise it will be inferred from the view name.
    """
    pass


class DepartmentABACPermission(HasABACPermission):
    """
    ABAC permission that requires user to be in the same department as the resource.
    """
    
    def has_object_permission(self, request, view, obj):
        if not request.user.is_authenticated:
            return False
        
        if request.user.is_superuser:
            return True
        
        # First check base ABAC permissions
        if not super().has_object_permission(request, view, obj):
            return False
        
        # Additional department check
        if hasattr(obj, 'department') and hasattr(request.user, 'employee'):
            if request.user.employee and request.user.employee.department:
                return obj.department == request.user.employee.department
        
        return False


class ManagerABACPermission(HasABACPermission):
    """
    ABAC permission that requires user to be a manager.
    """
    
    def has_permission(self, request, view):
        if not request.user.is_authenticated:
            return False
        
        if request.user.is_superuser:
            return True
        
        # Check if user is a manager
        if hasattr(request.user, 'employee'):
            if not getattr(request.user.employee, 'is_manager', False):
                return False
        
        # Then check ABAC policies
        return super().has_permission(request, view)


class OwnerOrABACPermission(HasABACPermission):
    """
    Permission that allows owners to access their own resources,
    or checks ABAC policies for others.
    """
    
    def has_object_permission(self, request, view, obj):
        if not request.user.is_authenticated:
            return False
        
        if request.user.is_superuser:
            return True
        
        # Check if user is the owner
        owner = getattr(obj, 'user', None) or getattr(obj, 'owner', None) or getattr(obj, 'created_by', None)
        if owner and owner == request.user:
            return True
        
        # Otherwise check ABAC policies
        return super().has_object_permission(request, view, obj)


# Legacy compatibility classes
class IsHRAdmin(HasABACPermission):
    """Legacy: Check if user has HR admin access via ABAC policies"""
    
    def __init__(self):
        super().__init__(resource_type='hr_module', action_map={'GET': 'admin', 'POST': 'admin', 'PUT': 'admin', 'PATCH': 'admin', 'DELETE': 'admin'})


class IsCompanyOwner(HasABACPermission):
    """Legacy: Check if user has company owner access via ABAC policies"""
    
    def __init__(self):
        super().__init__(resource_type='company', action_map={'GET': 'owner', 'POST': 'owner', 'PUT': 'owner', 'PATCH': 'owner', 'DELETE': 'owner'})


class IsManager(ManagerABACPermission):
    """Legacy: Check if user is a manager via ABAC policies"""
    pass


# Utility function for method decorators
def abac_permission_required(resource_type, action):
    """
    Decorator for checking ABAC permissions on individual methods.
    
    Usage:
        @abac_permission_required('employee', 'update')
        def update_employee(request, employee_id):
            ...
    """
    def decorator(func):
        def wrapper(request, *args, **kwargs):
            if not request.user.is_authenticated:
                from rest_framework.exceptions import NotAuthenticated
                raise NotAuthenticated()
            
            if not request.user.is_superuser:
                engine = PolicyEngine(request.user)
                if not engine.check_access(resource_type, action):
                    from rest_framework.exceptions import PermissionDenied
                    raise PermissionDenied(f"You don't have permission to {action} {resource_type}")
            
            return func(request, *args, **kwargs)
        return wrapper
    return decorator
