# Django management command init file
