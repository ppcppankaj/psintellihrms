"""ABAC app initialization"""
default_app_config = 'apps.abac.apps.AbacConfig'
