"""
Organization Middleware - Single Source of Truth for Organization and Branch Resolution
SECURITY: This middleware handles context resolution and safety guards.
"""

import logging
import uuid
import re
from typing import Any, Optional
from django.conf import settings
from django.http import JsonResponse, HttpRequest, HttpResponse
from django.utils.deprecation import MiddlewareMixin
from django.core.exceptions import ValidationError, ImproperlyConfigured
from .context import (
    get_current_organization, set_current_organization,
    get_current_user, set_current_user,
    get_current_branch, set_current_branch,
    get_client_ip, set_client_ip,
    get_user_agent, set_user_agent,
    get_device_id, set_device_id,
    clear_context
)


logger = logging.getLogger(__name__)

# Legacy utility functions (now use contextvars from context.py)
# Note: OrganizationMiddleware in middleware_organization.py handles the core resolution


# UnifiedTenantMiddleware is replaced by OrganizationMiddleware in middleware_organization.py
class OrganizationAuthMiddleware(MiddlewareMixin):
    """
    Validation guard: Ensure organization context matches user's assigned organization.
    """
    
    def process_request(self, request: HttpRequest) -> Optional[HttpResponse]:
        # Skip validation for public paths
        public_paths = ['/api/health/', '/api/v1/authentication/', '/admin/']
        if any(request.path.startswith(p) for p in public_paths):
            return None
        
        # Skip if user not authenticated
        if not hasattr(request, 'user') or not request.user.is_authenticated:
            return None
        
        # Skip for superusers
        if request.user.is_superuser:
            return None
            
        # Validate organization context (set by OrganizationMiddleware)
        org = get_current_organization()
        if not org:
             return None
             
        if request.user.organization_id and request.user.organization_id != org.id:
            logger.error(
                f"SECURITY: Cross-organization access attempt! "
                f"User organization: {request.user.organization_id} | Request organization: {org.id} | "
                f"User: {request.user.email} | Path: {request.path}"
            )
            return JsonResponse({
                'error': 'organization_mismatch',
                'message': 'Your credentials do not belong to this organization.'
            }, status=403)
        
        return None


# BranchContextMiddleware ensures branch information is available in context


class AuditMiddleware(MiddlewareMixin):
    """
    Captures request metadata and stores in context for audit logging.
    """
    
    def process_request(self, request: HttpRequest) -> None:
        # Extract client IP
        x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
        if x_forwarded_for:
            ip = x_forwarded_for.split(',')[0].strip()
        else:
            ip = request.META.get('REMOTE_ADDR', '')
        
        request.client_ip = ip
        request.user_agent = request.META.get('HTTP_USER_AGENT', '')
        request.device_id = request.META.get('HTTP_X_DEVICE_ID', '')
        
        # Store in context variables (async-safe)
        set_client_ip(ip)
        set_user_agent(request.user_agent)
        set_device_id(request.device_id)
        
        return None


class SecurityHeadersMiddleware(MiddlewareMixin):
    """
    Adds security headers to all responses.
    """
    
    def process_response(self, request: HttpRequest, response: HttpResponse) -> HttpResponse:
        # Content Security Policy
        if request.path.startswith('/admin'):
            # Relax CSP for Django admin which uses inline scripts/styles
            response['Content-Security-Policy'] = "default-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self' data:; frame-ancestors 'none'"
        else:
            response['Content-Security-Policy'] = "default-src 'self'; frame-ancestors 'none'"
        
        # Prevent MIME type sniffing
        response['X-Content-Type-Options'] = 'nosniff'
        
        # XSS Protection
        response['X-XSS-Protection'] = '1; mode=block'
        
        # Clickjacking protection
        response['X-Frame-Options'] = 'DENY'
        
        # Referrer Policy
        response['Referrer-Policy'] = 'strict-origin-when-cross-origin'
        
        # Permissions Policy
        response['Permissions-Policy'] = 'geolocation=(self), camera=(self), microphone=()'
        
        return response


class InputSanitizationMiddleware(MiddlewareMixin):
    """Sanitize incoming request data to prevent XSS and basic injection."""
    def process_request(self, request: HttpRequest) -> None:
        if request.method in ('POST', 'PUT', 'PATCH'):
            for key, value in request.POST.items():
                if isinstance(value, str) and re.search(r'<script|onerror|onload|javascript:', value, re.IGNORECASE):
                    raise ValidationError(f"Invalid input detected in field: {key}")
        return None


class CorrelationIdMiddleware(MiddlewareMixin):
    """Attach a correlation ID to each request for tracing."""
    def process_request(self, request: HttpRequest) -> None:
        request.correlation_id = request.META.get(
            'HTTP_X_CORRELATION_ID',
            str(uuid.uuid4())
        )


# Utility functions for accessing context (now use context vars from context.py)
def get_client_ip():
    """Get client IP from context."""
    from .context import get_client_ip as _get_ip
    return _get_ip()


def get_user_agent():
    """Get user agent from context."""
    from .context import get_user_agent as _get_ua
    return _get_ua()


def get_device_id():
    """Get device ID from context."""
    from .context import get_device_id as _get_id
    return _get_id()


class BranchContextMiddleware(MiddlewareMixin):
    """
    Middleware to automatically set organization and branch context for authenticated users.
    """
    
    def process_request(self, request):
        if not hasattr(request, 'user') or not request.user.is_authenticated:
            return
        
        user = request.user
        
        # Set organization from context or user (failsafe)
        org = get_current_organization()
        if not org and hasattr(user, 'organization'):
            org = user.organization
            if org:
                set_current_organization(org)
                request.organization = org
        
        # Set primary branch
        try:
            branch = self._get_user_primary_branch(user)
            if branch:
                set_current_branch(branch)
                request.branch = branch
        except Exception as e:
            logger.warning(f"Could not set branch context: {e}")
    
    def _get_user_primary_branch(self, user):
        """
        Get the user's primary branch from BranchUser or Employee models.
        """
        # Try to get from BranchUser mapping
        try:
            from apps.authentication.models import BranchUser
            branch_membership = BranchUser.objects.filter(
                user=user,
                is_active=True
            ).select_related('branch').first()
            
            if branch_membership:
                return branch_membership.branch
        except Exception:
            pass
        
        # Fallback: Try to get from Employee record
        try:
            from apps.employees.models import Employee
            employee = Employee.objects.filter(
                user=user,
                is_active=True
            ).select_related('branch').first()
            
            if employee and employee.branch:
                return employee.branch
        except Exception:
            pass
        
        return None
