# Django management package
