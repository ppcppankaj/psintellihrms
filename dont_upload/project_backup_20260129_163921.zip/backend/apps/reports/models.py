"""Reports Models"""
from django.db import models
from apps.core.models import OrganizationEntity

class ReportTemplate(OrganizationEntity):
    name = models.CharField(max_length=100)
    code = models.CharField(max_length=50, unique=True)
    description = models.TextField(blank=True)
    report_type = models.CharField(max_length=30)
    query_config = models.JSONField(default=dict)
    columns = models.JSONField(default=list)
    filters = models.JSONField(default=list)
    
    def __str__(self):
        return self.name

class ScheduledReport(OrganizationEntity):
    template = models.ForeignKey(ReportTemplate, on_delete=models.CASCADE)
    schedule = models.CharField(max_length=50)  # cron expression
    recipients = models.JSONField(default=list)
    format = models.CharField(max_length=10, choices=[('pdf', 'PDF'), ('excel', 'Excel'), ('csv', 'CSV')])
    last_run = models.DateTimeField(null=True, blank=True)
    
    def __str__(self):
        return f"{self.template.name} - {self.schedule}"

class GeneratedReport(OrganizationEntity):
    template = models.ForeignKey(ReportTemplate, on_delete=models.SET_NULL, null=True)
    generated_by = models.ForeignKey('employees.Employee', on_delete=models.SET_NULL, null=True)
    filters_applied = models.JSONField(default=dict)
    file = models.FileField(upload_to='reports/')
    
    def __str__(self):
        return f"{self.template.name if self.template else 'Report'} - {self.created_at}"
