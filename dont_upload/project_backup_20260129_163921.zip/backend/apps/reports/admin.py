"""Reports Admin"""
from django.contrib import admin
from .models import ReportTemplate, ScheduledReport, GeneratedReport

@admin.register(ReportTemplate)
class ReportTemplateAdmin(admin.ModelAdmin):
    list_display = ['name', 'code', 'report_type', 'is_active']
    list_filter = ['report_type', 'is_active']
    search_fields = ['name', 'code']

@admin.register(ScheduledReport)
class ScheduledReportAdmin(admin.ModelAdmin):
    list_display = ['template', 'schedule', 'format', 'last_run', 'is_active']
    list_filter = ['format', 'is_active']

@admin.register(GeneratedReport)
class GeneratedReportAdmin(admin.ModelAdmin):
    list_display = ['template', 'generated_by', 'created_at']
    raw_id_fields = ['template', 'generated_by']
