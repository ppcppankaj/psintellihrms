"""
Reports ViewSets - Dashboard and Analytics
Security: Requires authentication and organization/branch isolation
"""

from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django.db import models
from django.db.models import Count, Avg, Sum, Q
from django.utils import timezone

from apps.employees.models import Employee, Department
from apps.recruitment.models import JobPosting, JobApplication
from apps.payroll.models import PayrollRun, Payslip
from apps.core.permissions_branch import BranchPermission


class ReportViewSet(viewsets.ViewSet):
    """
    Custom ViewSet for aggregating data across modules for dashboards.
    All reports are filtered by user's organization/branch access.
    """
    permission_classes = [IsAuthenticated, BranchPermission]
    
    def _get_branch_filter(self, request):
        """Get branch IDs for filtering"""
        if request.user.is_superuser:
            return None  # No filter for superuser
        
        from apps.authentication.models_hierarchy import BranchUser
        branch_ids = list(BranchUser.objects.filter(
            user=request.user,
            is_active=True
        ).values_list('branch_id', flat=True))
        
        return branch_ids
    
    def _get_org_filter(self, request):
        """Get organization for filtering"""
        if request.user.is_superuser:
            return None
        return request.user.get_organization()

    @action(detail=False, methods=['get'], url_path='dashboard-metrics')
    def dashboard_metrics(self, request):
        """
        Get high-level statistics for the HR dashboard.
        Filtered by user's organization/branch access.
        """
        branch_ids = self._get_branch_filter(request)
        org = self._get_org_filter(request)
        
        # Build employee filter
        emp_filter = Q(employment_status='active')
        if branch_ids is not None:
            if not branch_ids:
                return Response({
                    'employees': {'total': 0, 'departments': 0},
                    'recruitment': {'open_jobs': 0, 'new_applications': 0},
                    'payroll': {'last_run': None}
                })
            emp_filter &= Q(branch_id__in=branch_ids)
        
        # Employee stats
        emp_count = Employee.objects.filter(emp_filter).count()
        
        # Department stats (org level)
        dept_filter = Q()
        if org:
            dept_filter = Q(branch__organization=org) | Q(branch__isnull=True)
        dept_count = Department.objects.filter(dept_filter).count() if org else 0
        
        # Recruitment stats
        job_filter = Q(status='open')
        if branch_ids is not None:
            job_filter &= Q(branch_id__in=branch_ids)
        
        open_jobs = JobPosting.objects.filter(job_filter).count()
        new_apps = JobApplication.objects.filter(
            stage='new',
            job__branch_id__in=branch_ids if branch_ids else []
        ).count() if branch_ids else 0
        
        # Payroll stats
        payroll_filter = Q(status='paid')
        if branch_ids is not None:
            payroll_filter &= Q(branch_id__in=branch_ids)
        
        last_run = PayrollRun.objects.filter(payroll_filter).order_by('-pay_date').values('total_net', 'pay_date').first()
        
        data = {
            'employees': {
                'total': emp_count,
                'departments': dept_count,
            },
            'recruitment': {
                'open_jobs': open_jobs,
                'new_applications': new_apps,
            },
            'payroll': {
                'last_run': last_run,
            }
        }
        return Response(data)

    @action(detail=False, methods=['get'], url_path='department-stats')
    def department_stats(self, request):
        """
        Get employee count by department.
        Filtered by user's branch access.
        """
        branch_ids = self._get_branch_filter(request)
        org = self._get_org_filter(request)
        
        # Build base queryset
        qs = Department.objects.all()
        
        if org:
            qs = qs.filter(Q(branch__organization=org) | Q(branch__isnull=True))
        
        # Annotate with employee count (filtered by branch)
        emp_filter = Q(employees__employment_status='active')
        if branch_ids is not None:
            emp_filter &= Q(employees__branch_id__in=branch_ids)
        
        stats = qs.annotate(
            employee_count=Count('employees', filter=emp_filter)
        ).values('name', 'employee_count')
        
        return Response(list(stats))

    @action(detail=False, methods=['get'], url_path='leave-stats')
    def leave_stats(self, request):
        """
        Get leave utilization stats by leave type.
        Filtered by user's branch access.
        """
        from apps.leave.models import LeaveBalance, LeaveType
        
        branch_ids = self._get_branch_filter(request)
        org = self._get_org_filter(request)
        
        # Get leave types for org
        leave_types = LeaveType.objects.all()
        if org:
            leave_types = leave_types.filter(organization=org)
        
        result = []
        for lt in leave_types:
            # Build filter for balances
            balance_filter = Q(leave_type=lt)
            if branch_ids is not None:
                balance_filter &= Q(employee__branch_id__in=branch_ids)
            
            # Aggregate balances for this type
            agg = LeaveBalance.objects.filter(balance_filter).aggregate(
                total_taken=Sum('taken'),
                total_accrued=Sum('accrued'),
                total_opening=Sum('opening_balance'),
                total_cf=Sum('carry_forward'),
                total_adj=Sum('adjustment')
            )
            
            taken = agg['total_taken'] or 0
            total_credits = (
                (agg['total_opening'] or 0) + 
                (agg['total_accrued'] or 0) + 
                (agg['total_cf'] or 0) + 
                (agg['total_adj'] or 0)
            )
            
            balance = total_credits - taken 
            utilization = (taken / total_credits * 100) if total_credits > 0 else 0
            
            result.append({
                'leave_type': lt.name,
                'total_taken': float(taken),
                'total_balance': float(balance),
                'utilization_percent': round(float(utilization), 1)
            })
            
        return Response(result)

    @action(detail=False, methods=['get'])
    def attrition_report(self, request):
        """
        Simple attrition calculation.
        Filtered by user's branch access.
        """
        branch_ids = self._get_branch_filter(request)
        
        # Calculate attrition for accessible branches
        from datetime import timedelta
        
        one_year_ago = timezone.now() - timedelta(days=365)
        
        base_filter = Q()
        if branch_ids is not None:
            base_filter = Q(branch_id__in=branch_ids)
        
        # Employees at start of period
        start_count = Employee.objects.filter(
            base_filter,
            date_of_joining__lte=one_year_ago
        ).count()
        
        # Employees who left
        left_count = Employee.objects.filter(
            base_filter,
            employment_status='terminated',
            date_of_exit__gte=one_year_ago
        ).count()
        
        attrition_rate = (left_count / start_count * 100) if start_count > 0 else 0
        
        return Response({'attrition_rate': round(attrition_rate, 2)})

    @action(detail=False, methods=['get'])
    def department_diversity(self, request):
        """
        Get employee distribution by department and gender.
        Filtered by user's branch access.
        """
        branch_ids = self._get_branch_filter(request)
        
        emp_filter = Q()
        if branch_ids is not None:
            emp_filter = Q(branch_id__in=branch_ids)
        
        stats = Employee.objects.filter(emp_filter).values(
            'department__name', 'gender'
        ).annotate(count=Count('id'))
        
        return Response(list(stats))

