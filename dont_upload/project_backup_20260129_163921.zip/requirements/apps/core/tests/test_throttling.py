import pytest
from backend.apps.core.throttling import YourFunctionName  # Replace with actual function names

def test_your_function_name():
    assert YourFunctionName(parameters) == expected_result  # Replace with actual parameters and expected results

def test_your_function_name_exceptions():
    with pytest.raises(ExpectedException):  # Replace with actual exception
        YourFunctionName(parameters)  # Replace with actual parameters