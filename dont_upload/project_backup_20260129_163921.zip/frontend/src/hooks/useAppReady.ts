import { useAuthStore } from '@/store/authStore'
import { useTenant } from '@/context/TenantProvider'

/**
 * App readiness = authenticated and tenant resolved to ready.
 * For superusers: only requires authentication (no tenant needed).
 * For regular users: requires authentication + tenant ready.
 */
export const useAppReady = () => {
    const { tokens, user } = useAuthStore()
    const { tenantSlug, status } = useTenant()

    // Superusers only need authentication (they work in public schema)
    if (user?.is_superuser) {
        return Boolean(tokens?.access)
    }

    // Regular users need authentication + tenant ready
    return Boolean(tokens?.access && tenantSlug && status === 'ready')
}

/**
 * Check if app is ready for TENANT-SCOPED operations only.
 * Returns false for superusers to prevent 401 errors on tenant endpoints.
 */
export const useTenantReady = () => {
    const { tokens, user } = useAuthStore()
    const { tenantSlug, status } = useTenant()

    // Superusers should NOT access tenant-scoped endpoints
    if (user?.is_superuser) {
        return false
    }

    return Boolean(tokens?.access && tenantSlug && status === 'ready')
}
