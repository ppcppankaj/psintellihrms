import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react'
import { setApiTenant } from '@/services/api'
import { useAuthStore } from '@/store/authStore'

interface TenantContextValue {
    tenantSlug: string | null
    status: 'pending' | 'ready' | 'error'
    error?: string | null
    refreshTenant: () => Promise<void>
}

const TenantContext = createContext<TenantContextValue | undefined>(undefined)

const deriveTenantFromHostname = (hostname: string): string | null => {
    const sanitizedHost = hostname.trim().toLowerCase()

    // Local development: fall back to public schema
    if (sanitizedHost === 'localhost' || sanitizedHost.startsWith('127.')) {
        return 'public'
    }

    const parts = sanitizedHost.split('.').filter(Boolean)

    // For hosts like app.acme.example.com -> tenant is parts[0]
    if (parts.length >= 3) {
        return parts[0]
    }

    // For two-part hosts (acme.local) assume first part is tenant
    if (parts.length === 2) {
        return parts[0]
    }

    return null
}

export const TenantProvider = ({ children }: { children: React.ReactNode }) => {
    const [tenantSlug, setTenantSlug] = useState<string | null>(null)
    const [status, setStatus] = useState<'pending' | 'ready' | 'error'>('pending')
    const [error, setError] = useState<string | null>(null)
    const user = useAuthStore((state) => state.user)

    const resolveTenant = useCallback(async () => {
        setStatus('pending')
        setError(null)

        const resolved = deriveTenantFromHostname(window.location.hostname)

        if (!resolved) {
            setStatus('error')
            setError('Unable to resolve tenant from subdomain')
            setApiTenant(null)
            return
        }

        setTenantSlug(resolved)
        setApiTenant(resolved)
        setStatus('ready')
    }, [])

    useEffect(() => {
        void resolveTenant()
    }, [resolveTenant])

    // Superusers should default to public schema even on tenant subdomains
    useEffect(() => {
        if (user?.is_superuser && tenantSlug !== 'public') {
            setTenantSlug('public')
            setApiTenant('public')
            setStatus('ready')
            setError(null)
        }
    }, [user?.is_superuser, tenantSlug])

    const value = useMemo(
        () => ({ tenantSlug, status, error, refreshTenant: resolveTenant }),
        [tenantSlug, status, error, resolveTenant]
    )

    return <TenantContext.Provider value={value}>{children}</TenantContext.Provider>
}

export const useTenant = () => {
    const ctx = useContext(TenantContext)
    if (!ctx) {
        throw new Error('useTenant must be used within TenantProvider')
    }
    return ctx
}
